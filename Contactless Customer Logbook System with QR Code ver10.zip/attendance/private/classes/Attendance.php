<?php
class Attendance{
    private $id;
    private $lecture_id;
    private $phoneNum;
    private $start;
    private $end;
    
    private $lecture;
    private $student;
    
    public function __construct($id=0) {
        if($id<1){
            $this->id =0;
            $this->lecture_id =0;
            $this->phoneNum = "none";
            $this->start = date("Y-m-d H:i:s");
            $this->end = date("Y-m-d H:i:s");
            
            $this->lecture = null;
            $this->student = null;
        }else{
            $this->fetch_by_id($id);
        }
    }

    public function fetch_by_id($id) {
        $row = DB::queryFirstRow("SELECT * FROM attendance WHERE id=%i",$id);
        return $this->set_row($row);
    }
    public function fetch_by_lecture($lecture_id) {
        $result = DB::query("SELECT * FROM attendance WHERE lecture=%i",$lecture_id);
        return $this->set_result($result);
    }
    public function fetch_by_phoneNum($phoneNum) {
        $result = DB::query("SELECT * FROM attendance WHERE phoneNum=%s",$phoneNum);
        return $this->set_result($result);
    }
  

    public function fetch_all() {
        $result = DB::query("SELECT * FROM attendance");
        return $this->set_result($result);
    }
    
    
    public function update_by_id(){
        $row = DB::update("attendance",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function update_by_lecture(){
        $row = DB::update("attendance",  $this->get_array(),"lecture=%i",  $this->lecture_id);
        return true;
    }
    public function update_by_phoneNum(){
        $row = DB::update("attendance",  $this->get_array(),"phoneNum=%s",  $this->phoneNum);
        return true;
    }

        public function delete_by_id(){
        DB::delete("attendance","id=%i",  $this->id);
        return true;
    }
    public function insert(){
        DB::insert("attendance",  $this->get_array());
        return true;
    }

    private function set_row($row) {
        if(!empty($row)){
            $this->id = (int)$row['id'];
            $this->lecture_id = (int)$row['lecture'];
            $this->phoneNum = $row['phoneNum'];
            $this->start = $row['start'];
            $this->end = $row['end'];
            
            $this->lecture = new Lecture($this->lecture_id);
            $this->student = (new Student())->fetch_student_by_phoneNum($this->phoneNum);
        }
        return $this;
    }
    private function set_row1($row) {
        $at = new self();
        if(!empty($row)){
            $at->id = (int)$row['id'];
            $at->lecture_id = (int)$row['lecture'];
            $at->phoneNum = $row['phoneNum'];
            $at->start = $row['start'];
            $at->end = $row['end'];
            
            $at->lecture = new Lecture($at->lecture_id);
            $at->student = (new Student())->fetch_student_by_phoneNum($at->phoneNum);
        }
        return $at;
    }
    
    private function set_result($result){
        $at = array();
        foreach($result as $row){
            $at[] = $this->set_row1($row);
        }
        return $at;
    }
    public function get_array($include_id = false){
        $at = array();
        if($include_id){
            $at['id'] = $this->id;
        }
        $at['lecture'] = $this->lecture_id;
        $at['phoneNum'] = $this->phoneNum;
        $at['start'] = $this->start;
        $at['end'] = $this->end;
        return $at;
    }
    public function get_id() {
        return $this->id;
    }

    public function get_lecture_id() {
        return $this->lecture_id;
    }

    public function get_phoneNum() {
        return $this->phoneNum;
    }

    public function get_start() {
        return $this->start;
    }

    public function get_end() {
        return $this->end;
    }

    public function get_lecture() {
        return $this->lecture;
    }

    public function get_student() {
        return $this->student;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_lecture_id($lecture_id) {
        $this->lecture_id = $lecture_id;
    }

    public function set_phoneNum($phoneNum) {
        $this->phoneNum = $phoneNum;
    }

    public function set_start($start) {
        $this->start = $start;
    }

    public function set_end($end) {
        $this->end = $end;
    }

    public function set_lecture($lecture) {
        $this->lecture = $lecture;
    }

    public function set_student($student) {
        $this->student = $student;
    }


}
?>

