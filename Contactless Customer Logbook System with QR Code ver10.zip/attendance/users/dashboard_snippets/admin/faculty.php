

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="5" class="text-center">
                <h2>Shopping Location</h2>
            </th>
        </thead>
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                    $faculties = (new Faculty())->fetch_all();
                    foreach($faculties as $faculty){
                        echo '<tr>';
                        echo '<td colspan="4"> '.  ucwords($faculty->get_name()).'  </td>';
                        echo '<td > <form method = "post">'
                        
                        . '<input type="hidden" name="faculty_id" value="'.$faculty->get_id().'" >'
                                . '<input type="hidden" name ="post" value ="delete_faculty">'
                                . '<button type="submit"  name="delete_faculty_btn" class="btn btn-sm btn-outline-danger" > <i class="fa fa-trash"></i> </button>'
                                . '</form></td>';
                        echo '</tr>';
                    }
                ?>
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="new_faculty" >
      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">New Shopping Location</h5></td>
                    
                </tr>
                
         
                
                <tr>
                    <td><h6>Location/Mall Name</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="faculty_name" >
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Enter the faculty here" data-content=""></span>
                    </td>
                </tr>
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="new_faculty_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> New Shopping Location
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




