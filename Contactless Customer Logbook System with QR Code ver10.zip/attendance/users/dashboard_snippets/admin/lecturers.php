

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="6" class="text-center">
                <h2>Shops</h2>
            </th>
        </thead>
        <thead>
            <th>Name</th>
           
            <th>Shop</th>
            <th>Username</th>
            <th>Password</th>
            <th></th>
            <td></td>
        </thead>
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                    $lects = (new Lecturer())->fetch_all();
                    if(count($lects) ==0){
                        echo '<tr> <td colspan="7"><p class="text-center">No lecture yet.</p> </td> </tr>';
                    }
                    foreach($lects as $lect){
                        echo '<tr>';
                        echo '<td > '.  ucwords($lect->get_name()).'  </td>';
                        echo '<td > '.  ucwords($lect->get_department()->get_name()).'  </td>';
                        echo '<td > '.  $lect->get_username().'  </td>';
                        echo '<td > '.  $lect->get_password().'  </td>';
                        echo '<td > <form method = "post" id="admin_lecturer_delete_form">'
                        
                        . '<input type="hidden" name="lecturer_id" value="'.$lect->get_id().'" >'
                                . '<input type="hidden" name ="post" value ="delete_lecturer">'
                                . '<button type="submit"  id="admin_lecuturer_delete_btn"  name="delete_lecturer_btn" class="btn btn-sm btn-outline-danger" > <i class="fa fa-trash"></i> </button>'
                                . '</form></td>';
                        
                                echo '<td> <a class="btn btn-outline-success btn-sm" href="dashboard.php?tab=update_lecturer&id='.$lect->get_id().'"><i class="fa fa-edit"></i>  </a></td>';
                        echo '</tr>';
                    }
                ?>
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="new_lecturer" >
      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">New Shop</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Name </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="50" name="name" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 
                
                <tr>
                    <td><h6>Shop</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="department_id" >
                            <option value="0">Select department</option>
                            <?php
                            $deparments = (new Shop())->fetch_all();
                            foreach($deparments as $department){
                                echo '<option value ="'.$department->get_id().'" >'.$department->get_name().' </option>';
                            }
                            ?>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select department" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Username</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="username" >
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Password</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control"  name="password" >
                            
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
               
               
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="new_lecturer_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> New Lecturer
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




