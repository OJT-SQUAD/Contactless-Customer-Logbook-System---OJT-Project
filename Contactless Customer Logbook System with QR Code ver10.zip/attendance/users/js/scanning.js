$(function(){
    //lecture ongoing
   $("#spinner").hide();
   
    var options = {
      shutter_ogg_url: "webcam/jpeg_camera/shutter.ogg",
      shutter_mp3_url: "webcam/jpeg_camera/shutter.mp3",
      swf_url: "webcam/jpeg_camera/jpeg_camera.swf"
    };
    var camera = new JpegCamera("#camera", options);
    var lecture_id = $("#lecture_id").val();
  
  $('#take_snapshots').click(function(){
    var snapshot = camera.capture();
    snapshot.show();
    //show the spinner and wait for processing
    $("#spinner").show();
    $(this).attr("disabled","disabled");
    snapshot.upload({api_url: "webcam/action.php", lecture_id:lecture_id}).done(function(response) {
        $("table#result_table").html(response);
         //$('#imagelist').prepend("<tr><td><img src='"+response+"' width='100px' height='100px'></td><td>"+response+"</td></tr>");
       $("#take_snapshots").removeAttr("disabled");
       $("#spinner").hide();
       //window.location.href = window.location.href;
}).fail(function(response) {
  alert("Upload failed with status " + response);
  $("#take_snapshots").removeAttr("disabled");
  $("#spinner").hide();
  //window.location.href = window.location.href;
});
});

function done(){
    $('#snapshots').html("uploaded");
}
});


