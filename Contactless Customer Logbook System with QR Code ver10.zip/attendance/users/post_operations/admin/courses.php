<?php
if(isset($_POST['new_course_btn'])){
    $error = "";
    $success = "";
    
    $name = trim($_POST['name']);
    $code = trim($_POST['code']);
    $unit = trim($_POST['unit']);
    $department_id = (int)trim($_POST['department_id']);
    $semester = (int)  trim($_POST['semester']);
    
    if(!$semester){
        $error .= "\n Select semester.";
        
    }
    if(!$department_id){
        $error .= "\n Select department.";
    }
    if(!is_numeric($unit)){
        $error .= "\n Unit must an integer.";
    }
    $unit = (int)$unit;
    if($unit <1 || $unit >20){
        $error .= " \n wrong unit. Unit must be between 1 to 20.";
    }
    if(strlen($code) !==6){
        $error .= 'Wrong course code!';
    }
    if(strlen($name) <2 || strlen($name) >50){
        $error .= "\n Course name must be between 2 to 50 characters.";
    }
    
    $exist = DB::queryFirstRow("SELECT * FROM course WHERE name = %s OR code= %s",$name,$code);
    if(!empty($exist)){
        $error .= "\n Course already exist.";
    }
    
    if(strlen($error) <1){
        $course = new Course();
        $course->set_name($name);
        $course->set_code($code);
        $course->set_unit($unit);
        $course->set_semester($semester);
        $course->set_department_id($department_id);
        if($course->insert()){
            $success = "Course is successfully enterred!";
        }
    }
    
}

if(isset($_POST['delete_course_btn'])){
    $error = "";
    $success = "";
    
    $course_id = trim($_POST['course_id']);
    
    $course = new Course($course_id);
    if($course->delete_by_id()){
        $success = "Course successfully deleted!";
    }
}
?>

