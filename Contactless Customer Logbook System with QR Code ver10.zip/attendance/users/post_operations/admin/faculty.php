<?php
if(isset($_POST['new_faculty_btn'])){
    $faculty_name = trim($_POST['faculty_name']);
    
    $error = "";
    $success = "";
    if(strlen($faculty_name) <2 ){
        $error .= "Faculty name is too short!";
    }
    if(strlen($faculty_name) >50 ){
        $error .= "Faculty name is too long!";
    }
    $exist = DB::queryFirstRow("SELECT * FROM faculty WHERE name =%s",$faculty_name);
    if(!empty($exist)){
        $error .= "\n Location name already exist!";
    }
    if(strlen($error) <1){
        $faculty = new Faculty();
        $faculty->set_name($faculty_name);
        if($faculty->insert()){
            $success = "New location successfully inserted!";
        }
    }
}

if(isset($_POST['delete_faculty_btn'])){
       $error = "";
    $success = "";
    
    $faculty_id = (int)trim($_POST['faculty_id']);
    $faculty = new Faculty($faculty_id);
    if($faculty->delete_by_id()){
        $success = $faculty->get_name()." location successfully deleted!";
    }
    
}
?>
