
 <div class='splash-img'>
    <div class="container login">
    <h1 class="hide">Register</h1>

    <div class="row">

        <div class="col-md-4 col-lg-4 col-xl-4 mx-auto">
            <h3 class="text-center form-head"><a href="../index.php"><i class="fa fa-home"></i></a>&nbsp;&nbsp;&nbsp;Register</h3>

            <div class="card login">
        
<!--                <small class='alert alert-danger alert-dismissible'>
                <span class='close' data-dismiss='alert'>&times;</span></small>
 -->
                
            <form  method="post" id="registration">
                
                <input type="hidden" name="login-type" value="">
    
                <input type="hidden" name="table" value="">
    
                <input type="hidden" name="page" value="$page">
                    
                <label class="text-black" for="staff_user">Category</label><br>
                <select id="category" name="category" class="form-control">
                    <option value="none">choose category...</option>
                    <option value="applicant">Applicant</option>
                    <option value="company">Company</option>
                </select><br>
                
                <div id="applicant" >
                         <label class="text-black" for="name">Full Name</label><br>
                         <input type="text" name="name" maxlength="50" class="input-text" id="name"><br>
                         
                         <label class="text-black" for="email">E-mail</label><br>
                         <input type="text" name="email" maxlength="50" class="input-text" id="email"><br>
                         
                         <label class="text-black" for="phone">Phone</label><br>
                         <input type="text" name="phone" maxlength="11" class="input-text" id="phone"><br>
                         
                         <label class="text-black" for="address">Address</label><br>
                         <input type="text" name="address" maxlength="100" class="input-text" id="address"><br>
                         
                         <label class="text-black" for="gender">Gender</label><br>
                         <select name="gender"  class="form-control" id="gender">
                             <option value="M">Male</option>
                             <option value="F">Female</option>
                         </select><br>

                        <label class="text-black" for="password">Password</label><br>
                        <input type="password" name="password" maxlength="50" class="input-text" id="password">
                </div>
                
                <div id="company" >
                         <label class="text-black" for="name">Company Name</label><br>
                         <input type="text" name="company_name" maxlength="50" class="input-text" id="company_name"><br>
                         
                         <label class="text-black" for="contact_email">Contact E-mail</label><br>
                         <input type="text" name="contact_email" maxlength="50" class="input-text" id="contact_email"><br>
                         
                         <label class="text-black" for="contact_phone">Contact Phone</label><br>
                         <input type="text" name="contact_phone" maxlength="11" class="input-text" id="contact_phone"><br>
                         
                         
                         <label class="text-black" for="location">Location</label><br>
                         <input type="text" name="location" maxlength="50" class="input-text" id="location"><br>
                         
                     

                        <label class="text-black" for="password">Description</label><br>
                        <input type="description" name="description"  class="input-text" id="description">
                </div>
 
                <button name="register" class="btn btn-yellow" type="submit"><i class="fa fa-link fa-fw"></i>&nbsp;&nbsp; Register</button>
                <br>
               
                <small class='ml-2'>
                   Already registered? <a href="recover.php" class='text-sm'><a href="index.php">Login</a>
                </small>
            </form>
            
        </div>
</div>
    </div>
    </div>
 </div>