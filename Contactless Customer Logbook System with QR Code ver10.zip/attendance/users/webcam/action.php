<?php
require_once 'webcamClass.php';
require '../../private/includes.php';
$webcamClass=new webcamClass();
session_start();
//echo $webcamClass->showImage();
//start here
$image_location = $webcamClass->showImage();

//$qrcode = new Zxing\QrReader("../qrcode_images/scannow.jpg");
$qrcode = new Zxing\QrReader($image_location);
$text = $qrcode->text(); //

 $lecture_id = (int)$_SESSION['lecture_id'];

 
 //check if the lecture has stopped
  $lecture = new Lecture($lecture_id);
$start_duration = strtotime($lecture->get_start()) + ($lecture->get_duration() * 60 * 60);

$on = $start_duration < time();
if($lecture->get_id() >0 && $on){
    echo '<tr> <td colspan="2">Lecture has ended </td></tr>';
}else{
    if(strlen(trim($text)) ==15){
    $student = (new Student())->fetch_student_by_phoneNum($text);
    //also check whether the student registered the course
    $reg = (new RegisteredCourse())->has_registered($text, $lecture->get_session(), $lecture->get_semester(), $lecture->get_course_id());
    
   if(!empty($student)){//check if student exist
        if(!empty($reg)){
            //take attendance for thet student
        $att = new Attendance();
         $att->set_lecture_id($lecture_id);
         $att->set_phoneNum($text);
         $att->set_start(date("Y-m-d H:i:s"));
         $att->insert();
         echo '<tr>
            
                     <th>Name </th>
                     <th>Reg. No.</th>

                 </tr>
                <tr>
                     <td>'.$student->get_name().'</td>
                     <td>'.$student->get_phoneNum().'</td>
                 </tr>


                 <tr>
                     <td colspan="2"> 
                          <div   >
                     <img src="uploads/'.$student->get_image().'" width="200" height="200">

                      </div>
                     </td>
                 </tr>';
        }else{
           echo '<tr><td colspan="2">You did not register this course. </tr>';
        }
   }else{
       echo ' <tr>
                    <td colspan="2">Student cannot be identified.</td>
                    
               </tr>';
   }
}else{
    echo '<tr><td colspan="2">Scanning falied. Try again. </tr>';
}
      
}

              