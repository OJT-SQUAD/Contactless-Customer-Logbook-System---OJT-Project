<?php
//$dsn = 'mysql:host=localhost;dbname=oophp';
//$dsn = 'mysql:host=localhost;dbname=oophp;port=8889';


//it as like this but I changed it myself
//$dsn = 'sqlite:C:/xampp/htdocs/oophp/sqlite/oophp.db';

//$dsn = 'sqlite:oophp.db';
//$dsn = 'sqlite:/Applications/MAMP/htdocs/oophp/sqlite/oophp.db';

//$db = new PDO($dsn, 'oophp', 'lynda');

$db_host = "localhost";
$db_name = "cps";
$db_user = "root;";
$db_pass = "";



//Use this to test
//try {
//    require_once '(path) /pdo_connect.php';
//} catch (Exception $e) {
//    $error = $e->getMessage();
//}

?>