<?php

$user_admin = "admin";
$user_lect = "lect";
?>

