<li class="list-main">
                        <a href="dashboard.php?tab=students">
                            <i class="fa fa-users icon"></i>
                            <span class="extra-sm break">Visitors</span>
                        </a>
            </li>
            <li class="list-main">
                <a data-toggle="collapse" href="#attendance" role="button"
                   aria-controls="attendance">
                <i class="fa fa-pencil icon"></i>
                <span class="extra-sm">Logbook</span>
                </a>

                <ul id="attendance" class="collapse toggle-collapse">
                    <li>
                        <a href="dashboard.php?tab=ongoing"> <?php //start?>
                            <i class="fa fa-pencil icon"></i>
                            <span class="extra-sm break">Start</span>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard.php?tab=continue">
                            <i class="fa fa-plus-square icon"></i>
                            <span class="extra-sm break">Continue</span>
                        </a>
                    </li>

                   
                    <li>
                        <a href="dashboard.php?tab=attendance_analyse">
                            <i class="fa fa-bar-chart-o icon">Analysis</i>
                            <span class="extra-sm break"></span>
                        </a>
                    </li>
                    
                </ul>
            </li>
            
            

            <li class="list-main">
                <a data-toggle="collapse" href="#report" role="button"
                   aria-controls="report">
                <i class="fa fa-book icon"></i>
                <span class="extra-sm">Reports</span>
                </a>

               <ul id="report" class="collapse toggle-collapse">
                   
                    <li>
                        <a href="dashboard.php?tab=attendance_analyse">
                            <i class="fa fa-bar-chart-o icon">Attendance Report</i>
                            <span class="extra-sm break"></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="dashboard.php?tab=lecture">
                            <i class="fa fa-bar-pencil icon">Lectures</i>
                            <span class="extra-sm break"></span>
                        </a>
                    </li>
                    
                </ul></li>