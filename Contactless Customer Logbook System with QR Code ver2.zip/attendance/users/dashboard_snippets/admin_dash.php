<?php

    if(isset($_GET['tab']) && $_GET['tab'] == 'account'){

        include 'admin/account.php';
    
   
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'lecturers') {

        include 'admin/lecturers.php';
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'update_lecturer') {

        include 'admin/update_lecturer.php';
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'register_lect') {

        include 'admin/students_courses.php';

   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'courses') {

         include 'admin/courses.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'register') {

         include 'admin/register_course.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'register2') {

         include 'admin/register2.php';
   
  

    
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'students') {

        include 'admin/students.php';
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'update_students') {

        include 'admin/update_student.php';
   
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'department') {

        include 'admin/department.php';
    }elseif (isset($_GET['tab']) && $_GET['tab'] == 'faculty') {

         include 'admin/faculty.php';

    }else{
        $message = <<<FMS
            <div class="container mb-5 p-4">
                
                
                <p>You are welcome as the admin of this system.
                Here is where to manage the details and information of registered lecturers and courses.
                You have been provided with tab on the left hand side for your management.</p>
                <p>You have been given the privilege of control over everything partaining to this system- all at the
                comfort of your home or on the go.</p>
                
                <h5>We hope you love your dashboard</h5>
                <quote class="float-right mute muted">
                    <i class="fa fa-heart fa-4x text-green"></i><br>
                   
                    Attendance Manager</quote>
                <br><br><br>
            </div>
        
FMS;
        echo $message;
    }
    
?>

