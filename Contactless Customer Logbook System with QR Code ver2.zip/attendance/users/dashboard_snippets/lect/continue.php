

<form method="post">
      <input type="hidden" name="post" value="lecture" >
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     
                 <thead class="bg-success text-white">
                 <th colspan="2" class="text-center">
                <h2>Continue Lecture</h2>
            </th>
        </thead>
    
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='5' ><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 $inProgress = true;
                 $lecture = (new Lecture())->fetch_lecture_by_lect_in_progress($_SESSION['id']);
                 $start_duration = strtotime($lecture->get_start()) + ($lecture->get_duration() * 60 * 60);
                 
                $on = $start_duration > time();
                 if($lecture->get_id() >0 && $on){
                ?>
        
         
                 <tr>
                    <td><h6>Course Details</h6></td>
                    <td >
                          <?php echo $lecture->get_course()->get_name().'| '.$lecture->get_course()->get_code().'| '.$lecture->get_course()->get_unit();   ?>
                      
                    </td>
                  
                </tr>
                 <tr>
                    <td><h6>Start Date/Time</h6></td>
                    <td >
                          <?=$lecture->get_start()?>
                      
                    </td>
                  
                </tr>
                 <tr>
                    <td><h6>Duration</h6></td>
                    <td >
                          <?php
                            echo ($lecture->get_duration()==1)?$lecture->get_duration()." Hour":$lecture->get_duration()." Hours";?> 
                      
                    </td>
                  
                </tr>
         
               <?php
                 }else{
                    //$qrcode = new Zxing\QrReader('qrcode_images/20190223120857.jpg');
                   // $text = $qrcode->text(); //return decoded text from QR Code
                      //check whether the attendance has any attendance yet, else delete it
                if($lecture->get_id() >0){
                    $att = (new Attendance())->fetch_by_lecture($lecture->get_id());
                    if(count($att) >0){
                        $lecture->delete_by_id();
                    }
                }
                     
                     $inProgress = FALSE;
                     echo '<tr>'
                     . '<td colspan="2"> No Lecture in Progress! </td>'
                     . ' </tr>';
                 }
                 ?>
                
                 <tr>
                     <td ><button <?=(!$inProgress)?"disabled":""; ?> name="continue_lecture_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-arrow-right fa-fw"></i> Continue
                    </button>
                    </td>
                     <td ><button <?=(!$inProgress)?"disabled":""; ?> name="continue_lecture_btn_delete" type="submit" class="btn btn-sm btn-outline-danger ">
                            <i class="fa fa-trash fa-fw"></i> Delete
                    </button>
                    </td>
                   
                    
                </tr>
                
      </table>      
</form>





