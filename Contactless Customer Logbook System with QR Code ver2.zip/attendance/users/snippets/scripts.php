
<script src="js/jquery.js"></script>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    
<!--    <script type="text/javascript" src="jpeg_camera/jquery.min.js"></script>-->
    <script src="webcam/jpeg_camera/jpeg_camera_with_dependencies.min.js" type="text/javascript"></script>
    <script src="js/scanning.js"></script>
    <script src="js/main.js"></script>
    <script src="js/register.js"></script>
