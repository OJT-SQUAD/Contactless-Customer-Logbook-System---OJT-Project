   <?php
        $course_id = $_SESSION['s_course_id'];
        $session = $_SESSION['s_session'];
        $semester = (int)$_SESSION['s_semester'];
        $sem = "";
        if($semester ==1){
            $sem = "First";
        }elseif($semester ==2){
            $sem = "Second";
        }
        $rcs = (new RegisteredCourse())->fetch_for_lect($course_id, $session, $semester);
        $course = new Course($course_id);
                   
     ?>

    <div class="row">
        <div class="col-md-8 offset-2" >
                <table class="table table-active  bg-white table-lg table-responsive-sm " border="1">
                   
                    <tr>
                        <th colspan="2">Course Name</th>
                        <td colspan="2"><?=  ucwords($course->get_name())?></td>
                    </tr>
                    <tr>
                        <th colspan="2">Course Code</th>
                        <td colspan="2"><?=$course->get_code()?></td>
                    </tr>
                    <tr>
                        <th colspan="2">Unit</th>
                        <td colspan="2"><?=$course->get_unit()?></td>
                    </tr>
                    <tr>
                        <th colspan="2">Session</th>
                        <td colspan="2"><?=$session;
                        ?></td>
                    </tr>
                    <tr>
                        <th colspan="2">Semester</th>
                        <td colspan="2"><?=$sem;
                        ?></td>
                    </tr>
                   

                        <tr class="bg-success">
                            <th><h5>S/N</h5></th>
                            <th><h5>Student Name</h5></th>
                            <th><h5>Reg. No.</h5></th>
                            <th><h5>Shop</h5></th>
                       
                        </tr>
                 
                   
                    <?php
                    
                    $counter =1;
                    if(!empty($rcs)){


                    foreach($rcs as $rc){
                        $student = (new Student())->fetch_student_by_phoneNum($rc->get_phoneNum());
                        
                        echo '<tr>';

                        echo '<td> '.$counter.'</td>';
                        echo '<td> '.$student->get_name().'</td>';
                        echo '<td> '.$student->get_phoneNum().'</td>';
                        echo '<td> '.$student->get_department()->get_name().'</td>';
                       
                        echo '</tr>';
                        $counter++;
                    }
                    ?>
                
                    
                 <?php

                    }else{
                        echo '<tr><td colspan="4"><p class="text-center">No Registration Yet!</p></td>  </tr>';
                    }
                 ?>
                </table>

             </div>
    </div>
    <div class="row noPrint">
        <div class="col-md-2 offset-5">
            <a href="javascript:window.print()" style="margin-top: 5px;" class="btn btn-outline-success btn-sm btn-block"><i class="fa fa-print fa-fw"></i> Print</a>
        </div>
    </div>

