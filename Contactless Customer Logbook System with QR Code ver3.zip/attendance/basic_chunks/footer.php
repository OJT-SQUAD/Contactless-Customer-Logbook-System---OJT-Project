   
    <!-- Footer -->
    <footer class="bg-dark">
      <div class="container ">
        <div class="row">
          <div class="col-md-6 text-light">
            <span class="copyright">Copyright &copy; Contactless Customer Logbook System using QR Code 2019 - <?php if(date("Y") !== "2019") echo date("Y"); ?></span>
          </div>
         
          <div class="col-md-6">
            <ul class="list-inline quicklinks">
              
              <li class="list-inline-item">
                <a href="index.php">CCLS - QR Code</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>

   

    <!-- Bootstrap core JavaScript -->
    <script src="js/jquery-1.7.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>

    

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>