<?php
if(isset($_SESSION)){
        
session_unset();
  session_destroy();
  
}

?>
<!DOCTYPE html>
<html lang="en">

  <head>
        <title>Contactless Customer Logbook System Using Quick Response Code</title>
<?php include 'basic_chunks/header_info.php';  ?>

  </head>

  <body id="page-top">

  <?php include 'basic_chunks/nav.php'; ?>

    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
            <div class="intro-lead-in">Welcome to our new Contactless Customer Logbook System. </div>
          
          <div class="intro-heading text-uppercase">OJT Project</div>
          <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Get Started Now!</a>
        </div>
      </div>
    </header>

    <!-- Services -->
    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Features</h2>
            <h3 class="section-subheading text-muted">Customer Contactless Logbook System - QR Code</h3>
          </div>
        </div>
        <div class="row text-center">
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-cloud fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading">Contactless Logging</h4>
            <p class="text-muted">Safe customer registration and identification logging.</p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading">Responsive Design</h4>
            <p class="text-muted">
                Flexible for every establishment.
            </p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading">Quick Response Code</h4>
            <p class="text-muted">
                A more fast and secure way to log in.
            </p>
          </div>
        </div>
      </div>
    </section>

    
   
        
    <!--  -->
    <section class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6">
          
          </div>
        </div>
      </div>
    </section>

<?php include 'basic_chunks/footer.php';  ?>

  </body>

</html>
