<?php
class Shop{
    private $id;
    private $name;
    private $code;
    private $faculty_id;
    private $date;
    
    private $faculty;
    
    public function __construct($id =0) {
        if($id <1){
            $this->id = 0;
            $this->name = "none";
            $this->code = "none";
            $this->faculty_id = 0;
            $this->date = date("Y-m-d H:i:s");
            
            $this->faculty = null;
        }
        else{
            $this->fetch_department_by_id($id);
        }
    }
    
    public function fetch_department_by_id($id){
        $row = DB::queryFirstRow("SELECT * FROM department WHERE id=%i",$id);
        return $this->set_row($row);
    }
    public function fetch_by_faculty($faculty_id){
        $result = DB::query("SELECT * FROM department WHERE faculty =%i",$faculty_id);
        return $this->set_result($result);
    }
    public function fetch_all(){
        $result = DB::query("SELECT * FROM department");
        return $this->set_result($result);
    }
    public function update_by_id(){
        DB::update("department",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function delete_by_id(){
        DB::delete("department","id=%i",  $this->id);
        return true;
    }
    public function insert(){
        DB::insert("department",  $this->get_array());
        return true;
    }

    private function set_row($row){
        if(!empty($row)){
            $this->id = (int)$row['id'];
            $this->name = $row['name'];
            $this->code = $row['code'];
            $this->faculty_id =(int) $row['faculty'];
            $this->date = $row['date'];
            
            $this->faculty = new Faculty($this->faculty_id);
        }
        return $this;
    }
    private function set_row1($row){
        $de = new self();
        if(!empty($row)){
            $de->id = (int)$row['id'];
            $de->name = $row['name'];
            $de->code = $row['code'];
            $de->faculty_id =(int) $row['faculty'];
            $de->date = $row['date'];
            
            $de->faculty = new Faculty($de->faculty_id);
        }
        return $de;
    }
    
    public function get_array($include_id = false){
        $de = array();
        if($include_id){
            $de['id'] = $this->id;
            
        }
        $de['name'] = $this->name;
        $de['code'] = $this->code;
        $de['faculty']= $this->faculty_id;
        $de['date'] = $this->date;
        
        return $de;
    }
    public function set_result($result){
        $de = array();
        foreach ($result as $row){
            $de[] = $this->set_row1($row);
        }
        return $de;
    }
    public function get_faculty_id() {
        return $this->faculty_id;
    }

    public function set_faculty_id($faculty_id) {
        $this->faculty_id = $faculty_id;
        $this->faculty = new Faculty($faculty_id);
    }

            public function get_id() {
        return $this->id;
    }

    public function get_name() {
        return $this->name;
    }

    public function get_code() {
        return $this->code;
    }

    public function get_faculty() {
        return $this->faculty;
    }

    public function get_date() {
        return $this->date;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_name($name) {
        $this->name = $name;
    }

    public function set_code($code) {
        $this->code = $code;
    }

    public function set_faculty($faculty) {
        $this->faculty = $faculty;
    }

    public function set_date($date) {
        $this->date = $date;
    }


}
?>

