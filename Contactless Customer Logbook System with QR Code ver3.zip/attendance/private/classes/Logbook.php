<?php
class Logbook{
    private $id;
    private $name;
    private $location_id;
    private $shop_id;
    private $date;
    private $time;
    
    
    public function __construct($id =0) {
        
        if($id <1){
            $this->id =0;
            $this->name = "none";
            $this->location_id = "none";
            $this->shop_id = "none";
            $this->date = date("m-d-Y");
            $this->time = date("H:i:s");
            
        }else{
            $this->fetch_logbook_by_id($id);
        }
 
    }
    public function fetch_logbook_by_id($id){
        $row = DB::queryFirstRow("SELECT * FROM logbook WHERE id=%i",$id);
        return $this->set_row($row);
    }
    
    public function fetch_all(){
        $result = DB::query("SELECT * FROM logbook");
        return $this->set_result($result);
    }

        private function set_row($row){
        if(!empty($row)){
           // $this->id = (int)$row['id'];
            $this->name = $row['name'];
            $this->date = $row['date'];
        }
        return $this;
    }
    
    private function set_row1($row){
        $fa = new self();
        if(!empty($row)){
            $fa->id = (int)$row['id'];
            $fa->name = $row['name'];
            $fa->date = $row['date'];
        }
        return $fa;
    }
    
    public function get_array($include_id = false){
        $fa = array();
        if($include_id){
        $fa['id'] = $this->id;
        }
        $fa['name'] = $this->name;
        $fa['date'] = $this->date;
        
        return $fa;
    }
    
    private function set_result($result){
        $fa = array();
        foreach($result as $row){
            $fa[] = $this->set_row1($row);
        }
        return $fa;
    }
    
    public function update_by_id(){
        DB::update("logbook",  $this->get_array(), "id=%i",  $this->id);
        return true;
    }
    
    public function delete_by_id(){
        DB::delete("logbook","id=%i",  $this->id);
        return true;
    }
    public function insert(){
        DB::insert("logbook",  $this->get_array());
        return true;
    }
    
    public function get_id() {
        return $this->id;
    }

    public function get_name() {
        return $this->name;
    }

    public function get_date() {
        return $this->date;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_name($name) {
        $this->name = $name;
    }

    public function set_date($date) {
        $this->date = $date;
    }


}
?>
