<?php
include '../private/includes.php';
//import session material and other classes
//check session for a user before proceding
/*
    if(is_session_inplace("admin")){
        $page = "dashboard.php?type=admin"; 
    }elseif (is_session_inplace("company")) {
        $page = "dashboard.php?type=company";
    }elseif(is_session_inplace("applicant")){
        $page = "dashboard.php?type=applicant";
    }
*/

session_start();
if(!isset($_SESSION['qr_login'])){
    header("Location: ../index.php");
}

$error = "";
$success = "";
if(isset($_POST['post']) && $_POST['post'] !==''){
    include 'post_operations/main.php';
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Contactless Customer Logbook System - Dashboard</title>
<meta name="author" content="Contactless Customer Logbook System">

<?php require_once('snippets/styles.php');?>

</head>

<body>

<?php
include_once("snippets/header.php");
?>
    <div class="row mt-4">
    <?php
 include_once("snippets/dash-header.php");//Side headers
?>
   <div class='col-md-8 ml-md-3'>
   <div class='main-content'>

 
<?php
if(isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]){
//if(true){//Estate admin
    
    include 'dashboard_snippets/admin_dash.php';

   }elseif(isset($_SESSION[$user_lect]) && $_SESSION[$user_lect]){
       include 'dashboard_snippets/lect_dash.php';
       
  }else{
    header("Location: index.php");
}


?>
   </div>
   </div>
    </div>
<?php
include_once("snippets/footer.php");
?>


       
<script>
    $(".details").click(function(){
        var id = this.id;

        $("#to-be-removed_" + id).fadeOut("slow",function(){

            $("#to-replace_" + id).fadeIn("slow");
        })
    })

    $(".back-btn").click(function(){
        var id = this.id;
        name = this.name;

        $("#to-" + id).fadeOut("slow",function(){
            $("#to-be-removed_" + name).fadeIn();
        });
    });
</script>

<?php
include 'snippets/scripts.php';
?>
</body>
</html>

