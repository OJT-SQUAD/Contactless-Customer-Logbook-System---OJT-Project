

    
    <table class="table table-active bg-white table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="5" class="text-center">
                <h2>Register Course</h2>
            </th>
        </thead>
      
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                   $student = new Student();
                   if(isset($_SESSION['register1']) && $_SESSION['register1']){
                       $phoneNum = $_SESSION['phoneNum'];
                       $row = DB::queryFirstRow("SELECT * FROM student WHERE phoneNum=%s",$phoneNum);
                       if(count($row) >0){
                           $student = $student->fetch_student_by_phoneNum($phoneNum);
                         }
                   }else{
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>
        <tr>
            <th colspan="3">Name</th>
            <td colspan="2"><?=$student->get_name()?></td>
        </tr>
        <tr>
            <th colspan="3">Phone Number</th>
            <td colspan="2"><?=$student->get_phoneNum()?></td>
        </tr>
        <tr>
            <th colspan="3">Shop</th>
            <td colspan="2"><?=$student->get_department()->get_name()?></td>
        </tr>
        <tr>
            <th colspan="3">Barangay</th>
            <td colspan="2"><?=$student->get_barangay()?></td>
        </tr>
        <tr>
            <th colspan="3">Session</th>
            <td colspan="2"><?=$_SESSION['session']?></td>
        </tr>
        <tr>
            <th colspan="3">Semester</th>
            <td colspan="2"><?php
                $semester = (int)$_SESSION['semester'];
                if($semester ==1){
                    echo 'First';
                }else if($semester ==2){
                    echo 'Second';
                }
            ?></td>
        </tr>
        <thead>
            
            <tr class="bg-success">
                <th><h5>S/N</h5></th>
                <th><h5>Course Name</h5></th>
                <th><h5>Course Code</h5></th>
                <th><h5>Unit</h5></th>
            <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total =0;
        $counter =1;
        $r_courses = (new RegisteredCourse())->fetch_all_by_details($_SESSION['phoneNum'], $_SESSION['session'], (int)$_SESSION['semester']);
        if(!empty($r_courses)){
            
        
        foreach($r_courses as $r_course){
            $course = $r_course->get_course();
            $total += $course->get_unit();
            echo '<tr>';
            
            echo '<td> '.$counter.'</td>';
            echo '<td> '.$course->get_name().'</td>';
            echo '<td> '.$course->get_code().'</td>';
            echo '<td> '.$course->get_unit().'</td>';
            echo '<td> '
            
            . '<form method="post">'
                    
                    . '<input type="hidden" name="post" value="register" >'
                    . '<input type="hidden" name="r_course_id" value="'.$r_course->get_id().'">'
                    . '<button type="submit" name="delete_registered_course" class="btn btn-sm btn-outline-danger"> <i class="fa fa-trash "></i> </button>'
                    . '</form></td>';
            echo '</tr>';
            $counter++;
        }
        ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3">&nbsp;</th>
                <th colspan="2">Total Units: &nbsp; <?=$total;?></th>
            </tr>
        </tfoot>
     <?php

        }
     ?>
    </table>

<form method="post">
      <input type="hidden" name="post" value="register" >
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">Add Course</h5></td>
                    
                </tr>
                <input type="hidden" id="session" value="<?=$_SESSION['session'];?>">
                <input type="hidden" id="semester" value="<?=$_SESSION['semester'];?>">
         
            
                 
                
                <tr>
                    <td><h6>Shop</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="department_id" id="register2-department">
                            <option value="0">Select department</option>
                            <?php
                            $deparments = (new Shop())->fetch_all();
                            foreach($deparments as $department){
                               
                                echo '<option value ="'.$department->get_id().'" >'.$department->get_name().' </option>';
                            }
                            ?>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select department" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Course</h6></td>
                    <td colspan="3">
                        <select class="form-control" id="register2-course" name="course_id" >
                            
                           
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select course" data-content=""></span>
                    </td>
                </tr>
               
                
               
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="add_course_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-circle fa-fw"></i> Add Course
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




