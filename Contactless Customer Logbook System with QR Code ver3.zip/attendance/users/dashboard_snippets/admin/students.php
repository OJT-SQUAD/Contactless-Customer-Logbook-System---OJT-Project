<form method="post" enctype="multipart/form-data">
      <input type="hidden" name="post" value="new_student" >
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">New Customer</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Name </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="50" name="name" 
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 
                
                <!--comment>
				<tr>
                    <td><h6>Shop</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="department_id" >
                            <option value="0">Select department</option>
                            <?php
                            /*
							$deparments = (new Shop())->fetch_all();
                            foreach($deparments as $department){
                                echo '<option value ="'.$department->get_id().'" >'.$department->get_name().' </option>';
                            }
							*/
                            ?>
                        </select>
                            
                            
                      
                    </td>
				
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select department" data-content=""></span>
                    </td>
                </tr>
				</comment-->
				<tr>
                    <td><h6>Address</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="55" name="address" >
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Phone Number</h6></td>
                    <td colspan="3">
                        <input type="num" class="form-control" maxlength="11" name="phoneNum" >
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Barangay</h6></td>
                    <td colspan="3">
                        <select class="form-control"  name="barangay" >
                            <option>Select Barangay</option>
                            <option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="35">35</option>
							<option value="Villamonte">Villamonte</option>
                            
                        </select>
                     
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>ID Photo (only .jpg and .png are accepted)</h6></td>
                    <td colspan="3">
                        <input type="file" name="passport" required class="form-control">
                     
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
               
                 <tr>
                     <td colspan="4"><button name="new_student_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> New Customer
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>



    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="7" class="text-center">
                <h2>Customers</h2>
            </th>
        </thead>
        <thead>
            <th>Name</th>
            
           
            <th>Address</th>
            <th>Phone Number</th>
            <th>Barangay</th>
            <th></th>
            <td></td>
            <td></td>
        </thead>
      
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                   $students = (new Student())->fetch_all();
                    if(count($students) ==0){
                        echo '<tr> <td colspan="7"><p class="text-center">No student yet.</p> </td> </tr>';
                    }
                    foreach($students as $student){
                        echo '<tr>';
                        echo '<td > '.  ucwords($student->get_name()).'  </td>';
                        echo '<td > '.  ucwords($student->get_address()).'  </td>';
                        echo '<td > '.  $student->get_phoneNum().'  </td>';
                        echo '<td > '.  $student->get_barangay().'  </td>';
                        echo '<td > <form method = "post">'
                        
                        . '<input type="hidden" name="student_id" value="'.$student->get_id().'" >'
                                . '<input type="hidden" name ="post" value ="delete_student">'
                                . '<button type="submit"  name="delete_student_btn" class="btn btn-sm btn-outline-danger" > <i class="fa fa-trash"></i> </button>'
                                . '</form></td>';
                        
                                echo '<td> <a class="btn btn-outline-success btn-sm" href="dashboard.php?tab=update_students&id='.$student->get_id().'"><i class="fa fa-edit"></i>  </a></td>';
                                echo '<td> <a class="btn btn-outline-success btn-sm" href="student_card.php?id='.$student->get_id().'"><i class="fa fa-id-card"></i>  </a></td>';
                        echo '</tr>';
                    }
                ?>
               
    </table>
