

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="7" class="text-center">
                <h2>Customer Information</h2>
            </th>
        </thead>
      
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                   $student = new Student();
                   if(isset($_GET['id']) && is_numeric($_GET['id'])){
                       $id = (int)trim($_GET['id']);
                       $row = DB::queryFirstRow("SELECT * FROM student WHERE id=%i",$id);
                       if(count($row) >0){
                           $student = $student->fetch_student_by_id($id);
                         }
                   }
                   if(!$student->get_id()){
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>
        <tr>
            <th>Name</th>
            <td><?=$student->get_name()?></td>
        </tr>
        <tr>
            <th>Address</th>
            <td><?=$student->get_address()?></td>
        </tr>
        <tr>
            <th>Barangay</th>
            <td><?=$student->get_barangay()?></td>
        </tr>
        <tr>
            <th>Phone Number</th>
            <td><?=$student->get_phoneNum()?></td>
        </tr>
        <tr>
            <th>Passport Photo</th>
            <td><img class="img-rounded" src="uploads/<?=$student->get_image()?>" width="150" height="150" ></td>
        </tr>
        <tr>
            <th>QR Code</th>
        <td><img class="img-rounded" width="150" src="qrcode_images/<?=  strtolower(str_replace("/", "", $student->get_Name()))?>.png" alt="Image name"></td>
        </tr>
        
        
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="update_student" >
      <input type="hidden" name="student_id" value="<?=$student->get_id()?>">
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">Update Customer Details</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Name </h6></td>
                    <td colspan="3">
                        <input type="text" disabled class="form-control" maxlength="50" name="name" value="<?=$student->get_name()?>" >
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Address</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="55" name="address" value="<?=$student->get_address()?>">
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Phone Number</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="15" name="phoneNum" value="<?=$student->get_phoneNum()?>">
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Barangay</h6></td>
                    <td colspan="3">
                        <?php $options = $student->get_barangay()?>
                        <select class="form-control"  name="barangay" >

                            <option value="1" <?php if($options=="1") echo 'selected="selected"'; ?> >1</option>
                            <option value="2" <?php if($options=="2") echo 'selected="selected"'; ?> >2</option>
                            <option value="3" <?php if($options=="3") echo 'selected="selected"'; ?> >3</option>
                            <option value="35" <?php if($options=="35") echo 'selected="selected"'; ?> >35</option>
                            <option value="Villamonte" <?php if($options=="Villamonte") echo 'selected="selected"'; ?> >Villamonte</option>
                            
                            
                        </select>
                     
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>

                <tr>
                    <td></td>
                    <td colspan="3">
                        <input type="text" hidden class="form-control" name="regNo" value="<?=$student->get_regNo()?>" >
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                
                 <tr>
                     <td colspan="4"><button name="update_student_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-pencil-square fa-fw"></i> Update Customer
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




