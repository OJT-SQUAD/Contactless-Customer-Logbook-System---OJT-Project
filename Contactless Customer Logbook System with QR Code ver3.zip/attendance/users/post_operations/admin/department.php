<?php
if(isset($_POST['new_department_btn'])){
    $department_name = trim($_POST['department_name']);
    $faculty_id = (int)trim($_POST['faculty_id']);
    $department_code = trim($_POST['department_code']);
    
    $error = "";
    $success = "";
    if(strlen($department_name) <2 ){
        $error .= "\n Shop name is too short!";
    }
    if(strlen($department_name) >50 ){
        $error .= "\n Shop name is too long!";
    }
    if(strlen($department_code) !== 3 ){
        $error .= "\n Invalide department code. It must be exactly 3 characters.";
    }
    if(!$faculty_id){
        $error .= "\n You must select one faculty!";
    }
    
    $exist = DB::queryFirstRow("SELECT * FROM department WHERE code =%s OR name =%s",$department_code,$department_name);
    if(!empty($exist)){
        $error .= "\n Shop already exist!";
    }
    if(strlen($error) <1){
        $department = new Shop();
        $department->set_name($department_name);
        $department->set_code($department_code);
        $department->set_faculty_id($faculty_id);
        if($department->insert()){
            $success = "New department successfully enterred!";
        }
    }
}

if(isset($_POST['delete_department_btn'])){
       $error = "";
    $success = "";
    
    $department_id = (int)trim($_POST['department_id']);
    $department = new Shop($department_id);
    if($department->delete_by_id()){
        $success = $department->get_name()." department successfully deleted!";
    }
    
}
?>
