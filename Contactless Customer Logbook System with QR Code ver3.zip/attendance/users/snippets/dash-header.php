
    <div class="col-md-3 navigation">
        <h4 class="ml-3 hide-sm">
            <i class="fa fa-paw mr-2"></i>
            <span class="extra-sm">
                
                <?php
                    if(isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]){
                        echo 'System Admin';
                      }elseif(isset($_SESSION[$user_lect]) && $_SESSION[$user_lect]){

                         echo 'Lecturer';

                      }

                ?>
            
            </span>
        </h4>

        <ul class="main-nav">

             <li class="list-main">
                <a href="dashboard.php?tab=account">
                <i class="fa fa-user-circle icon"></i>
                <span class="extra-sm">My Account</span>
                </a>
            </li>

<?php
if(isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]){
    
    include 'dash_header_snippets/admin.php';

   }elseif(isset($_SESSION[$user_lect]) && $_SESSION[$user_lect]){
       include 'dash_header_snippets/lect.php';
}else{
    header("Location: index.php");
}
        ?>
        </ul>
    </div>

    
