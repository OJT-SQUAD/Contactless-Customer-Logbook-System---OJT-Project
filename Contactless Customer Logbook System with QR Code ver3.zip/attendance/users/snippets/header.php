


<nav class="fixed-top navbar-expand-lg navbar-expand-xl navbar hidden noPrint">

  <a class="navbar-brand mr-5" href="dashboard.php?tab=account"><i class="fa fa-industry text-green"></i> Contactless Customer Logbook System</a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-toggle" aria-controls="navbar-toggle" aria-label="Toggle navigation">

    <span class="fa fa-bars"></span>

  </button>

  <div class="collapse navbar-collapse" id="navbar-toggle">

    <ul class="navbar-nav">
        <li><h4>
            <?php
                if(isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]){
                        echo $_SESSION['name'];
                        

                   }elseif(isset($_SESSION[$user_lect]) && $_SESSION[$user_lect]){

                       echo $_SESSION['name'];
                        
                  }

             ?>
            </h4>
        </li>

            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                <i class="fa fa-cog"></i> Dashboard</a>
            </li>

           

            <li class="nav-item">
                <a class="nav-link" href="dashboard.php?tab=account">
                <i class="fa fa-user-secret"></i> My Account</a>
            </li>

            <li class="nav-item">
                <a href="logout.php" class="nav-link">
                    <i class="fa fa-sign-out"></i>
                    Logout
                </a>
            </li>

        </ul>
    </div>
</nav>
<hr class="noPrint">
