 <div class="container mb-5 p-4">
                <h4 class="text-center">
                Welcome, random name</h1>
                <p>Here is where to manage your details as an employee.
                With the tabs on the left-sidebar, you can view, edit and delete
                 your account without any difficulty.</p>
                <p>Also included are the ability to view your leave requests
                such as recommended leaves, accepted leaves, rejected leaves, in
                addition to being able to request for new leaves - all at the
                comfort of your home or on the go.</p>
                <p>You can view your job description, generate reports of the
                leave activities of a particular time/all time, view leave
                statistics, pending leaves, and update your job description.
                </p>
                <h5>We hope you love your dashboard</h5>
                <quote class="float-right mute muted">
                    <i class="fa fa-heart fa-4x text-green"></i><br>
                    <span>Your friends!</span><br>
                    Group One</quote>
                <br><br><br>
            </div>

