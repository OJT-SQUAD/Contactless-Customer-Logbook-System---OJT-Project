<?php
$lect = new Lecturer($_SESSION['id']);
//$loc = new Lecture($_SESSION['id']);
//check if there is a lecture in progress
//$lecture = (new Lecture())->fetch_location($_SESSION['id']);
/*$start_duration = strtotime($lecture->get_start()) + ($lecture->get_duration() * 60 * 60);
/*
$on = $start_duration > time();
if(!($lecture->get_id() >0 && $on)){
    
   <?php header("Location: logout.php");
}

$_SESSION['lecture_id'] = $lecture->get_id();
*/

?>

   <?php

/*                   $lecture = new Lecture();
                   if(isset($_SESSION['id']) && is_numeric($_SESSION['id'])){
                       $id = (int)trim($_SESSION['id']);
                       $row = DB::queryFirstRow("SELECT * FROM lecture WHERE id=%i",$id);
                       echo $row;
                       if(count($row) >0){
                           $lecture = $lecture->fetch_location($id);
                          
                         }
                   }
                  */
                ?>
                    
                   <?php
                   $lectures = (new Lecture())->fetch_all();
                    if(count($lectures) ==0){
                        echo '<tr> <td colspan="7"><p class="text-center">No student yet.</p> </td> </tr>';
                    }
                        foreach($lectures as $lecture){
                           // echo var_dump($lecture);
                            $lecc = $lecture->get_location();
                            echo $lecc;

                            $shop = $lecture->get_shop();
                            echo $shop;

                           // echo '<tr>';
                            //echo '<td > '.  ucwords($lecture->get_location()).'  </td>';
                        }
                   
                    $faculties = (new Faculty())->fetch_faculty_by_id($lecc);
                    $array = array($faculties);

                    

                        foreach($array as $faculty){
                            $facc = $faculty->get_name();
                            
                        }

                    $departments = (new Shop())->fetch_department_by_id($shop);
                    $arrayDept = array($departments);

                    

                        foreach($arrayDept as $department){
                            $dept = $department->get_name();
                            
                        }


                    


?>

  <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     
                 <thead class="bg-success text-white">
                 <th colspan="2" class="text-center">
                     <h2>Contactless Logbook</h2>
            </th>
        </thead>
        <tr>
            <th>Date</th>
            <td><?=date("D, jS M., Y")?></td>
        </tr>
        <tr>
            <th>In-charge</th>
            <td><?=$lect->get_name()?></td>
        </tr>
        <tr>
            <th>Location</th>
            <td><?=$faculty->get_name() ?></td>
        </tr>
        <tr>
            <th>Shop</th>
            <td><?=$department->get_name()?></td>
        </tr>

  </table>

<form method="post" enctype="multipart/form-data">
      
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">Enter Customer QR</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Customer QR Code </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="40" name="qr_code" >
                        <input type="text" class="form-control" maxlength="4" name="location_code" value="<?=$lecc?>">
                        <input type="text" class="form-control" maxlength="4" name="shop_code" value="<?=$shop?>">
                        
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
<tr>
                     <td colspan="4"><button name="qr_code_button" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> Submit QR
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>

<?php
/*
  <div class="container">
     <input type="text" id="student_id" value="<?=$lecture->get_id()?>" >
        <div class="row">
        <div class="col-md-8">
            <div class="text-center">
                
      </div>
        </div>
        <div class="col-md-4">
            <table class="table table-bordered" id="result_table">
                       
        </table>
        </div>
 </div>
    </div>
    */
?>

 <div class="container">
     <input type="hidden" id="lecture_id" value="<?=$lecture->get_id()?>" >
        <div class="row">
        <div class="col-md-8">
            <div class="text-center">
                <div   >
                    <span class="text-center text-success" id="spinner"><i class="fa fa-spin fa-spinner fa-2x"></i></span>
                </div>
                <div id="camera" style="margin:0 auto; width: 50%;height: 350px;"></div><br>
    <button id="take_snapshots" class="btn btn-success btn-sm"><i class="fa fa-camera fa-fw"></i> Take Shot</button>
      </div>
        </div>
        <div class="col-md-4">
            <table class="table table-bordered" id="result_table">
                       
        </table>
        </div>
 </div>
    </div> <!-- /container -->