<?php
class Course{
    private $id;
    private $name;
    private $code;
    private $department_id;
    private $unit;
    private $semester;
    private $date;
    
    private $department;
    
    public function __construct($id =0) {
        if($id<1){
            $this->id =0;
            $this->name = "none";
            $this->code = "none";
            $this->department_id = 0;
            $this->unit = 0;
            $this->semester = 0;
            $this->date = date("Y-m-d H:i:s");
            
            $this->deparment = null;
        }else{
            $this->fetch_course_by_id($id);
        }
    }

    public function fetch_course_by_id($id) {
        $row = DB::queryFirstRow("SELECT * FROM course WHERE id=%i",$id);
        return $this->set_row($row);
    }
    
    public function fetch_by_department_id($department_id){
        $result = DB::query("SELECT * FROM course WHERE department=%i",$department_id);
        return $this->set_result($result);
    }
    public function fetch_all(){
        $result = DB::query("SELECT * FROM course");
        return $this->set_result($result);
    }
    public function update_by_id(){
        DB::update("course",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function update_by_department(){
        DB::update("course",  $this->get_array(),"department=%i",  $this->department_id);
        return true;
    }
    public function delete_by_id(){
        DB::delete("course","id=%i",  $this->id);
        return true;
    }
    public function delete_by_department(){
        DB::delete("course","department=%i",  $this->department_id);
        return true;
    }
    public function insert(){
        DB::insert("course",  $this->get_array());
        return true;
    }

    private function set_row($row) {
        if(!empty($row)){
            $this->id = (int)$row['id'];
            $this->name = $row['name'];
            $this->code = $row['code'];
            $this->department_id = (int)$row['department'];
            $this->unit = (int)$row['unit'];
            $this->semester = (int)$row['semester'];
            $this->date = $row['date'];
            
            $this->department = new Shop($this->department_id);
        }
            return $this;
    }
    private function set_row1($row) {
        $cs = new self();
        if(!empty($row)){
            $cs->id = (int)$row['id'];
            $cs->name = $row['name'];
            $cs->code = $row['code'];
            $cs->department_id = (int)$row['department'];
            $cs->unit = (int)$row['unit'];
            $cs->semester = (int)$row['semester'];
            $cs->date = $row['date'];
            
            $cs->department = new Shop($cs->department_id);
        }
            return $cs;
    }
    
    private function set_result($result){
        $cs = array();
        foreach ($result as $row){
            $cs[] = $this->set_row1($row);
        }
        return $cs;
    }
    
    public function get_array($include_id = false){
        $cs = array();
        if($include_id){
            $cs['id'] =  $this->id;
        }
        $cs['name'] = $this->name;
        $cs['code'] = $this->code;
        $cs['department'] = $this->department_id;
        $cs['unit'] = $this->unit;
        $cs['semester'] = $this->semester;
        $cs['date'] =  $this->date;
        
        return $cs;
    }

    public function get_id() {
        return $this->id;
    }

    public function get_name() {
        return $this->name;
    }

    public function get_code() {
        return $this->code;
    }

    public function get_department_id() {
        return $this->department_id;
    }

    public function get_unit() {
        return $this->unit;
    }

    public function get_semester() {
        return $this->semester;
    }

    public function get_date() {
        return $this->date;
    }

    public function get_department() {
        return $this->department;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_name($name) {
        $this->name = $name;
    }

    public function set_code($code) {
        $this->code = $code;
    }

    public function set_department_id($department_id) {
        $this->department_id = $department_id;
    }

    public function set_unit($unit) {
        $this->unit = $unit;
    }

    public function set_semester($semester) {
        $this->semester = $semester;
    }

    public function set_date($date) {
        $this->date = $date;
    }

    public function set_department($department) {
        $this->department = $department;
    }


}
?>
