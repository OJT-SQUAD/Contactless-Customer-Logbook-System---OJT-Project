<?php
if(isset($_POST['register1_btn'])){
    $error = "";
    $success = "";
    
    $phoneNum = strtolower(trim($_POST['phoneNum']));
    $session = trim($_POST['session']);
    $semester = (int)trim($_POST['semester']);
    
    if(!$semester){
        $error .= "\n You must select semester!";
    }
    if($semester =="none"){
        $error .= "\n You must select session";
    }
    if(strlen($phoneNum) !==15){
        $error .= "\n Regno is not correct";
    }
    $row = DB::queryFirstRow("SELECT * FROM student WHERE phoneNum =%s",$phoneNum);
    if(empty($row)){
        $error .= "\n Regno does not exist";
    }
    if(strlen($error) <1){
        $_SESSION['phoneNum'] = $phoneNum;
        $_SESSION['session'] =$session;
        $_SESSION['semester'] = $semester;
        $_SESSION['register1'] = true;
        header("Location: dashboard.php?tab=register2");
        exit();
    }
}
if(isset($_POST['add_course_btn'])){
   // $depart_id = (int)trim($_POST['department_id']);
    $course_id = (int)trim($_POST['course_id']);
    $error = "";
    $success = "";
    
    if(isset($_SESSION['phoneNum']) && isset($_SESSION['session']) && isset($_SESSION['semester']) && $course_id != 0){
        $c_exist = (new RegisteredCourse())->has_registered(trim($_SESSION['phoneNum']), trim($_SESSION['session']), trim($_SESSION['semester']), $course_id);
        
       if(!$c_exist){
            $rg = new RegisteredCourse();
            $rg->set_phoneNum(trim($_SESSION['phoneNum']));
            $rg->set_course_id($course_id);
            $rg->set_session(trim($_SESSION['session']));
            $rg->set_semester(trim($_SESSION['semester']));
            if($rg->insert()){
                $success = "Course added!";
            }
       }else{
           $error = "This has already been added!";
       }
    }else{
        $error = "Error occured. Course not added";
    }
}
if(isset($_POST['delete_registered_course'])){
    $r_course_id = (int)trim($_POST['r_course_id']);
  $row = DB::queryFirstRow("SELECT * FROM registered_course WHERE id=%i",$r_course_id);
  if(!empty($row)){
      $rc = new RegisteredCourse($r_course_id);
      if($rc->delete_by_id()){
          $success = "Course has been deleted";
      }
  }
}
?>

