<?php
    if(isset($_POST['post']) && $_POST['post'] !==''){
        $actual_operation = trim($_POST['post']);
        
        switch ($actual_operation){
        case 'students':
            include 'lect/students.php';
            break;
        case 'account':
            include 'lect/account.php';
            break;
        case 'lecture':
            include 'lect/lecture.php';
            break;
        }
    }
?>