<?php
if(isset($_POST['new_lecture_btn'])){
        $error = "";
    $success ="";
    
    $course_id = (int) trim($_POST['course']);
    $session = trim($_POST['session']);
    $semester =(int) trim($_POST['semester']);
    $duration = (int)trim($_POST['duration']);
    
    if(!$course_id || $semester <1 || $session =="none"){
        $error .= "Make all selections.";
    }
    if(!$duration){
        $error .= "Select duration.";
    }
     $lecture = (new Lecture())->fetch_lecture_by_lect_in_progress($_SESSION['id']);
     $start_duration = strtotime($lecture->get_start()) + ($lecture->get_duration() * 60 * 60);

    $on = $start_duration > time();
    if($lecture->get_id() >0 && $on){
        $error .= "You still have a class in progress!";
    }else{
          //check whether the attendance has any attendance yet, else delete it
        if($lecture->get_id() >0){
            $att = (new Attendance())->fetch_by_lecture($lecture->get_id());
            if(count($att) >0){
                $lecture->delete_by_id();
            }
        }
    }
        if(strlen($error) <1){
        $l = new Lecture();
        $l->set_course_id($course_id);
        $l->set_session($session);
        $l->set_semester($semester);
        $l->set_lecturer_id($_SESSION['id']);
        $l->set_in_progress(1);
        $l->set_duration($duration);
        $l->set_start(date("Y-m-d H:i:s"));
        if($l->insert()){
            header("Location: dashboard.php?tab=ongoing");
        }
        
       // header("Location: students.php");
        //$success = "see ".$course_id.' '.$semester.' '.$session;
    }
}

if(isset($_POST['qr_code_button'])){
    echo "<script>alert('yes!');</script>";
    $error = "";
    $success = "";

    $qr = $_POST['qr_code'];
    $location_code = $_POST['location_code'];
    $shop_code = $_POST['shop_code'];
    
   
$studentQR = new Student();
$logbookQR = new Logbook();

$existing = DB::queryFirstRow("SELECT * FROM student WHERE regNo = %s",$qr);


if(count($existing) >0){
    $studentGotQR = $studentQR->fetch_logbook_by_regNo($qr);
    $gotStudent = $studentGotQR->get_name();
                         }
   
        echo "<script>alert('$qr');</script>";
           
       //$student->set_regNo($currentDate.$currentDate);     
      $logbookQR->set_name($gotStudent);
       $logbookQR->set_locationID($location_code);
       $logbookQR->set_shopID($shop_code); 

       $logbookQR->logToLogbook();
/*
       $logbookQR->set_customerID('42');
       $logbookQR->set_locationID('2');
       $logbookQR->set_shopID('2');     
       $success = "Customer found! Logged in successfully.";   */ 
}

if(isset($_POST['continue_lecture_btn'])){
    $error = "";
    $success = "";
    
    $lecture = (new Lecture())->fetch_lecture_by_lect_in_progress($_SESSION['id']);
     if($lecture->get_id() >0){
           header("Location: dashboard.php?tab=ongoing");
     }
     
    
}
if(isset($_POST['continue_lecture_btn_delete'])){
    $error = "";
    $success = "";
    
    $lecture = (new Lecture())->fetch_lecture_by_lect_in_progress($_SESSION['id']);
     if($lecture->delete_by_id()){
          $success = "Lecture has been deleted. You can now start a new one!";
     }
     
    
}

if(isset($_POST['lectures_btn'])){
    $course = (int)trim($_POST['course']);
    $session = trim($_POST['session']);
    $semester = (int)trim($_POST['semester']);
    
    if(!$course){
        $error .= "\n Select course.";
    }
    if(!$semester){
        $error .= "\nSelect semester.";
    }
    if($session =="none"){
        $error .= "\n Select session";
    }
    if(strlen(trim($error)) <1){
        
        header("Location: dashboard.php?tab=lectures&crs=$course&sem=$semester&ses=$session");
    }
   
}
if(isset($_POST['new_analysis_btn'])){
    $course = (int)trim($_POST['course']);
    $session = trim($_POST['session']);
    $semester = (int)trim($_POST['semester']);
    
    if(!$course){
        $error .= "\n Select course.";
    }
    if(!$semester){
        $error .= "\nSelect semester.";
    }
    if($session =="none"){
        $error .= "\n Select session";
    }
    if(strlen(trim($error)) <1){
        $_SESSION['report_session'] = $session;
        $_SESSION['report_semester'] = $semester;
        $_SESSION['report_course'] = $course;
        header("Location: report.php");
    }
   
}
?>


