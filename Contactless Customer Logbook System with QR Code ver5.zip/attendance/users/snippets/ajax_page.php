<?php
include '../../private/includes.php';
if(isset($_POST['action']) && $_POST['action'] =="fetch_course"){
    $depart_id = (int)trim($_POST['depart_id']);
    $courses = (new Course())->fetch_by_department_id($depart_id);
     $cs = '<option value="0">Select Course</option>';
     foreach($courses as $course){

         $cs .= '<option value ="'.$course->get_id().'" >Course Title: '.$course->get_name().'| Course Code: '.$course->get_code().' | Unit: '.$course->get_unit().' </option>';
     }
     echo $cs;
                            
}

?>
