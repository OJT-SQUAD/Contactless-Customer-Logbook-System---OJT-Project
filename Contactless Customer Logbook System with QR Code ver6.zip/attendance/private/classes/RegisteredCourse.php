<?php
class RegisteredCourse{
    private $id;
    private $course_id;
    private $phoneNum;
    private $session;
    private $semester;
    private $date;
    
    private $course;
    private $student;
    
    public function __construct($id=0) {
        if($id<1){
            $this->id =0;
            $this->course_id =0;
            $this->phoneNum = "none";
            $this->session = "none";
            $this->semester = 0;
            $this->date = date("Y-m-d H:i:s");
            
            $this->course  = null;
            $this->student = null;
        }else{
            $this->fetch_by_id($id);
        }
    }

    public function fetch_by_id($id) {
        $row = DB::queryFirstRow("SELECT * FROM registered_course WHERE id = %i",$id);
        return $this->set_row($row);
    }
    public function fetch_by_phoneNum($phoneNum) {
        $result = DB::query("SELECT * FROM registered_course WHERE phoneNum =%s",$phoneNum);
        return $this->set_result($result);
    }
    public function fetch_for_lect($course_id, $session, $semester) {
        $result = DB::query("SELECT * FROM registered_course WHERE course =%i AND session = %s AND semester =%i",$course_id,$session,$semester);
        return $this->set_result($result);
    }
    public function has_registered($phoneNum, $session, $semester, $course){
        $row = DB::queryFirstRow("SELECT * FROM registered_course WHERE phoneNum = %s AND session = %s AND semester = %i AND course =%i",$phoneNum,$session,$semester,$course);
        return !empty($row);
    }
    public function fetch_all_by_details($phoneNum, $session, $semester){
        $result = DB::query("SELECT * FROM registered_course WHERE phoneNum = %s AND session = %s AND semester = %i",$phoneNum,$session,$semester);
        return $this->set_result($result);
    }
    public function update_by_id(){
        DB::update("registered_course",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function update_by_phoneNum(){
        DB::update("registered_course",  $this->get_array(),"phoneNum=%s",  $this->phoneNum);
        return true;
    }
    public function update_by_student_details($phoneNum, $session, $semester){
        DB::update("registered_course",  $this->get_array(),"phoneNum =%s AND session=%s AND semester =%i",$phoneNum,$session,$semester);
        return true;
    }
    public function delete_by_id(){
        DB::delete("registered_course","id=%i",  $this->id);
        return true;
    }
    public function delete_by_phoneNum(){
        DB::delete("registered_course","phoneNum=%s",  $this->phoneNum);
        return TRUE;
    }
    public function insert(){
        DB::insert("registered_course",  $this->get_array());
        return TRUE;
    }

    private function set_row($row){
        if(!empty($row)){
            $this->id = (int)$row['id'];
            $this->course_id = (int)$row['course'];
            $this->phoneNum = $row['phoneNum'];
            $this->session = $row['session'];
            $this->date = $row['date'];
            $this->semester = (int)$row['semester'];
            
            $this->course = new Course($this->course_id);
            $this->student = (new Student())->fetch_student_by_phoneNum($this->phoneNum);
            
        }
        return $this;
    }
    private function set_row1($row){
        $rc = new self();
        if(!empty($row)){
            $rc->id = (int)$row['id'];
            $rc->course_id = (int)$row['course'];
            $rc->phoneNum = $row['phoneNum'];
            $rc->session = $row['session'];
            $rc->date = $row['date'];
             $rc->semester = (int)$row['semester'];
            
            $rc->course = new Course($rc->course_id);
            $rc->student = (new Student())->fetch_student_by_phoneNum($rc->phoneNum);
            
        }
        return $rc;
    }
    
    public function get_array($include_id = false){
        $rc = array();
        if($include_id){
            $rc['id'] = $this->id;
        }
        $rc['course'] = $this->course_id;
        $rc['phoneNum'] = $this->phoneNum;
        $rc['session'] = $this->session;
        $rc['semester'] = $this->semester;
        $rc['date'] = $this->date;
        
        return $rc;
    }
    public function get_semester() {
        return $this->semester;
    }

    public function set_semester($semester) {
        $this->semester = $semester;
    }

        private function set_result($result){
        $rc = array();
        foreach ($result as $row){
            $rc[] = $this->set_row1($row);
        }
        return $rc;
    }
    
    public function get_id() {
        return $this->id;
    }

    public function get_course_id() {
        return $this->course_id;
    }

    public function get_phoneNum() {
        return $this->phoneNum;
    }

    public function get_session() {
        return $this->session;
    }

    public function get_date() {
        return $this->date;
    }

    public function get_course() {
        return $this->course;
    }

    public function get_student() {
        return $this->student;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_course_id($course_id) {
        $this->course_id = $course_id;
    }

    public function set_phoneNum($phoneNum) {
        $this->phoneNum = $phoneNum;
    }

    public function set_session($session) {
        $this->session = $session;
    }

    public function set_date($date) {
        $this->date = $date;
    }

    public function set_course($course) {
        $this->course = $course;
    }

    public function set_student($student) {
        $this->student = $student;
    }



}
?>

