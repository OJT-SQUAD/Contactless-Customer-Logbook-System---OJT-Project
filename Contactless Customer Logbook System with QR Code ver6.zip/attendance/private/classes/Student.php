<?php
class Student{
    private $id;
    private $idNo;	
	private $regNo;
    private $name;
   // private $department_id;
   private $address;
    private $phoneNum;
    private $barangay;
    private $currentDate;
    private $image;
    
    private $department;
    
    public function __construct($id =0) {
        if($id <1){
            $this->id =0;
			//$this->currentDate = substr(date('Y'),2);
            $this->idNo = "none";
			$this->regNo = "none";
            $this->name ="none";
            //$this->department_id =0;
			$this->address = "none";
            $this->phoneNum = "0";
            $this->barangay = "none";
            $this->image = "none";
            $this->date = date("Y-m-d H:i:s");
            
           // $this->department = null;
        }
        else{
            $this->fetch_student_by_id($id);
        }
    }
    
   // public function regNo(){
  //      $result = DB::query("SELECT LPAD() FROM student");
   //     return $this->set_result($result);
   // }
    public function fetch_student_by_id($id){
        $row = DB::queryFirstRow("SELECT * FROM student WHERE id = %i",$id);
        return $this->set_row($row);
	}	
	public function fetch_logbook_by_regNo($regNo){
        $account = DB::queryFirstRow("SELECT * FROM student WHERE regNo=%s",$regNo);
        return $this->set_log($account);
    }
    
    public function fetch_student_by_phoneNum($phoneNum){
        $row = DB::queryFirstRow("SELECT * FROM student WHERE phoneNum = %s",$phoneNum);
        return $this->set_row($row);
    }
    
    public function fetch_all(){
        $result = DB::query("SELECT * FROM student");
        return $this->set_result($result);
    }
    
    public function update_by_id(){
        DB::update("student",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
	public function update_by_regNo(){
        DB::update("student",  $this->get_array(),"regNo=%s",  $this->regNo);
        return true;
    }
    public function update_by_phoneNum(){
        DB::update("student",  $this->get_array(),"phoneNum=%s",  $this->phoneNum);
        return true;
    }
    public function delete_by_id(){
        DB::delete("student","id=%i",  $this->id);
        return true;
    }
    public function delete_by_phoneNum(){
        DB::delete("student","phoneNum=%s",  $this->phoneNum);
        return true;
    }
    public function insert(){
        DB::insert("student",  $this->get_array());
        return true;
    }
	
    public function get_id() {
        return $this->id;
    }
    public function get_regNo() {
        return $this->regNo;
    }
    public function get_name() {
        return $this->name;
    }
	public function get_address() {
        return $this->address;
    }
    public function get_barangay() {
        return $this->barangay;
    }
/*
    public function get_department() {
        return $this->department;
    }
*/
    public function get_phoneNum() {
        return $this->phoneNum;
    }
    
	/* public function get_department_id() {
        return $this->department_id;
    }

    public function set_department_id($department_id) {
        $this->department_id = $department_id;
        $this->department = new Shop($department_id);
    }
*/
        public function get_date() {
        return $this->$date;
    }
	    public function get_currentDate() {
        return $this->$currentDate;
    }
    /*
	public function get_regNo() {
        return $this->$regNo;
    }
*/
    public function set_id($id) {
        $this->id = $id;
    }

	public function set_regNo($regNo) {
        $this->regNo = $regNo;
    }
	
    public function set_name($name) {
        $this->name = $name;
    }
/*
    public function set_department($department) {
        $this->department = $department;
    }
*/
	public function set_address($address) {
        $this->address = $address;
    }
    public function set_phoneNum($phoneNum) {
        $this->phoneNum = $phoneNum;
    }

    public function set_date($date) {
        $this->date = $date;
    }

    public function set_barangay($barangay) {
        $this->barangay = $barangay;
    }

    public function get_image() {
        return $this->image;
    }

    public function set_image($image) {
        $this->image = $image;
    }

    private function set_log($account){
        if(!empty($account)){
           // $this->id = (int)$row['id'];
            $this->name = $account['name'];
            
		}
        return $this;
    }
	private function set_row($row){
        if(!empty($row)){
			$this->regNo = $row['regNo'];
            $this->id = (int)$row['id'];
            $this->name = $row['name'];
			$this->address = $row['address'];
           // $this->department_id = (int)$row['department'];
            $this->phoneNum = $row['phoneNum'];
            $this->barangay = $row['barangay'];
            $this->image = $row['image'];
            $this->date = $row['date'];
            
            //$this->department = new Shop($this->department_id);
        }
        return $this;
    }
    private function set_row1($row){
        $st = new self();
        if(!empty($row)){
            $st->regNo = $row['regNo'];
			$st->id = (int)$row['id'];
            $st->name = $row['name'];
			$st->address = $row['address'];
            //$st->department_id = (int)$row['department'];
            $st->phoneNum = $row['phoneNum'];
            $st->barangay = $row['barangay'];
            $st->image =$row['image'];
            $st->date = $row['date'];
            
            //$st->department = new Shop($st->department_id);
        }
        return $st;
    }
    
    public function get_array($include_id = false){
        $st = array();
        
        if($include_id){
            $st['id'] = $this->id;
        }
        $st['name'] = $this->name;
        $st['regNo'] = $this->regNo;
		$st['address'] = $this->address;
        //$st['department'] = $this->department_id;
        $st['phoneNum'] = $this->phoneNum;
        $st['image'] = $this->image;
        $st['barangay'] = $this->barangay;
        $st['date'] = $this->date;
        
        return $st;
    }
    
   private function set_result($result){
       $st = array();
       foreach($result as $row){
           $st[] = $this->set_row1(($row));
       }
       return $st;
   }
}
?>

