<?php

// Redirect all default requests to homepage
header("Location: ../../index.php");
exit;

// Or render a 404 page not found error:
// header("HTTP/1.0 404 Not Found");
// exit;

?>
