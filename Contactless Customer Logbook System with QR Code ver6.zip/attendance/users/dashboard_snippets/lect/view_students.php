

      <?php
                  
                  $lecture = null;
                   if(isset($_GET['lecture']) && is_numeric($_GET['lecture'])){
                       $id = (int)trim($_GET['lecture']);
                      
                      
                       $row = DB::queryFirstRow("SELECT * FROM lecture WHERE id=%i",$id);
                       if(count($row) >0){
                           $lecture = new Lecture($id);
                         }
                   }else{
                        header("Location: dashboard.php");
                   }
                   if(!$lecture->get_id()){
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="2" class="text-center">
                <h2>Attendance Students</h2>
            </th>
        </thead>
       
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
               
        <tr><th>Course Title</th>
            <td><?= ucwords($lecture->get_course()->get_name());?>
            </td>
        </tr>
        <tr><th>Course Code</th>
            <td><?= $lecture->get_course()->get_code();?>
            </td>
        </tr>
        <tr><th>Course Unit</th>
            <td><?= $lecture->get_course()->get_unit();?>
            </td>
        </tr>
        <tr><th>Session</th>
            <td><?= $lecture->get_session();?>
            </td>
        </tr>
        <tr><th>Semester</th>
            <td><?= $lecture->get_semester();?>
            </td>
        </tr>
        <tr><th>Date</th>
            <td><?= date("D. jS M., Y",  strtotime($lecture->get_start()));?>
            </td>
        </tr>
        
       
       
    </table>

      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
          <tr>
              <th>S/N</th>
              <th>Student Name</th>
              <th>Student Reg. No</th>
              <th>Scanning Time</th>
              <th></th>
          </tr>
          <?php
          
          $attendance = (new Attendance())->fetch_by_lecture($lecture->get_id());
          $counter =1;
          foreach ($attendance as $at){
              echo '<tr>';
              echo '<td>'.$counter.' </td>';
              echo '<td>'.$at->get_student()->get_name().' </td>';
              echo '<td>'.$at->get_phoneNum().' </td>';
              echo '<td>'.date("h:i A",  strtotime($lecture->get_start())).' </td>';
              //echo '<td><a class="btn btn-sm btn-outline-success" href="dashboard.php?tab=view_students&lecture='.$lect->get_id().'">View students </a>  </td>';
             
              echo '</tr>';
              $counter++;
          }
          ?>
                
         
           
                         
                
             
               
               
                
              
                
      </table>      




