<?php
if(isset($_POST['account_btn'])){
    $password = trim($_POST['new_password']);
    
    $error = "";
    $success = "";
    
    if(strlen($password) <2){
        $error .= "\n New password is too short. Password must be greater than 2 characters.";
    }
    if(strlen($password) >20){
        $error .= "\n New password is too long. Password must not be greater than 20 characters.";
    }
    
    if(strlen($error) <1){
        DB::update("admin",array("password"=>$password),"id=%i",$_SESSION['id']);
        $success = "Password successfully updated!";
    }
}
?>

