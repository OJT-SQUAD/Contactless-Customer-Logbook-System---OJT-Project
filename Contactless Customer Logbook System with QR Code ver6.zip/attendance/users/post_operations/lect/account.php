<?php
if(isset($_POST['lect_account_btn'])){
    $password = trim($_POST['new_password']);
    
    $error = "";
    $success = "";
    
    if(strlen($password) <2){
        $error .= "\n New password is too short. Password must be greater than 2 characters.";
    }
    if(strlen($password) >20){
        $error .= "\n New password is too long. Password must not be greater than 20 characters.";
    }
    
    if(strlen($error) <1){
        $lect = new Lecturer($_SESSION['id']);
        $lect->set_password($password);
        if($lect->update_by_id()){
            $success = "Password successfully updated!";
        }
    }
}
?>

