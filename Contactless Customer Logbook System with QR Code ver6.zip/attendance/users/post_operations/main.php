<?php
    if(isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]){

        include 'admin.php';

       }elseif(isset($_SESSION[$user_lect]) && $_SESSION[$user_lect]){
           
           include 'lect.php';
           
      }
    
?>

