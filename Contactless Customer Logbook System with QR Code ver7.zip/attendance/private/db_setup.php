<?php
require 'meekrodb.2.3.class.php';
DB::$user = 'root';
DB::$password = '';
DB::$dbName = 'attendance';
//DB::debugMode(TRUE);
?>
