

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="6" class="text-center">
                <h2>Courses</h2>
            </th>
        </thead>
        <thead>
            <th>Name</th>
            <th>Code</th>
            <th>Units</th>
            <th>Shop</th>
            <th>Semester</th>
            <th></th>
        </thead>
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='6'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                    $courses = (new Course())->fetch_all();
                    if(count($courses) ==0){
                        echo '<tr> <td colspan="7"><p class="text-center">No course yet.</p> </td> </tr>';
                    }
                    foreach($courses as $course){
                        echo '<tr>';
                        echo '<td > '.  ucwords($course->get_name()).'  </td>';
                        echo '<td > '.  ucwords($course->get_code()).'  </td>';
                        echo '<td > '.  ucwords($course->get_unit()).'  </td>';
                        echo '<td > '.  ucwords($course->get_department()->get_name()).'  </td>';
                        echo '<td > '.  ucwords($course->get_semester()).'  </td>';
                        echo '<td > <form method = "post">'
                        
                        . '<input type="hidden" name="course_id" value="'.$course->get_id().'" >'
                                . '<input type="hidden" name ="post" value ="delete_course">'
                                . '<button type="submit" title="delete course" name="delete_course_btn" class="btn btn-sm btn-outline-danger" > <i class="fa fa-trash"></i> </button>'
                                . '</form></td>';
                        
                        echo '</tr>';
                    }
                ?>
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="new_course" >
      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">New Course</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Name </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="name" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 <tr>
                    <td><h6>Code </h6></td>
                    <td colspan="3">
                        <input type="text"  maxlength="6" class="form-control" name="code" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 <tr>
                    <td><h6>Unit </h6></td>
                    <td colspan="3">
                        <input type="number" maxlength="2"  class="form-control" name="unit" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Shop</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="department_id" >
                            <option value="0">Select department</option>
                            <?php
                            $deparments = (new Shop())->fetch_all();
                            foreach($deparments as $department){
                                echo '<option value ="'.$department->get_id().'" >'.$department->get_name().' </option>';
                            }
                            ?>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select department" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Semester</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="semester" >
                            <option value="0">Select semester</option>
                            <option value="1">First</option>
                            <option value="2">Second</option>
                            
                        </select>
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
               
               
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="new_course_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> New Course
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




