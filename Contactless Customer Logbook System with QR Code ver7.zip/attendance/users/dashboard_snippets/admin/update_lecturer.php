

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="7" class="text-center">
                <h2>Lecturer</h2>
            </th>
        </thead>
      
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                   $lect = new Lecturer();
                   if(isset($_GET['id']) && is_numeric($_GET['id'])){
                       $id = (int)trim($_GET['id']);
                       $row = DB::queryFirstRow("SELECT * FROM lecturer WHERE id=%i",$id);
                       if(count($row) >0){
                           $lect = $lect->fetch_lecturer_by_id($id);
                         }
                   }
                   if(!$lect->get_id()){
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>
        <tr>
            <th>Name</th>
            <td><?=$lect->get_name()?></td>
        </tr>
        
        <tr>
            <th>Shop</th>
            <td><?=$lect->get_department()->get_name()?></td>
        </tr>
        <tr>
            <th>Username</th>
            <td><?=$lect->get_username()?></td>
        </tr>
        <tr>
            <th>Password</th>
            <td><?=$lect->get_password()?></td>
        </tr>
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="update_lecturer" >
      <input type="hidden" name="lecturer_id" value="<?=$lect->get_id()?>">
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">Update Lecturer</h5></td>
                    
                </tr>
                
         
                 <tr>
                    <td><h6>Name </h6></td>
                    <td colspan="3">
                        <input type="text" disabled class="form-control" maxlength="50" name="name" value="<?=$lect->get_name()?>" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 
                
                <tr>
                    <td><h6>Shop</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="department_id" >
                            <option value="0">Select department</option>
                            <?php
                            $deparments = (new Shop())->fetch_all();
                            foreach($deparments as $department){
                                $selected = "";
                                if($lect->get_department_id() == $department->get_id()){
                                    $selected = "selected";
                                }
                                echo '<option '.$selected.' value ="'.$department->get_id().'" >'.$department->get_name().' </option>';
                            }
                            ?>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select department" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Username</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="20" name="username" value="<?=$lect->get_username()?>">
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Password</h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" maxlength="20" name="password" value="<?=$lect->get_password()?>">
                    </td>
                   <td>
                       &nbsp;
                    </td>
                </tr>
                
               
               
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="update_lecturer_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-pencil-square fa-fw"></i> Update Lecturer
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




