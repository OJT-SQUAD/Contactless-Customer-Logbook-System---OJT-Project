 <?php
 include '../private/includes.php';
 ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Login - CCLS with QR Code</title>
<meta name="author" content="Contactless Customer Logging System">

<?php require_once('snippets/styles.php');?>

</head>

<body>
        <?php
         
        include_once("snippets/login.php");

        include_once("snippets/scripts.php");

        ?>
   
</body>
</html>