<?php
    if(isset($_POST['post']) && $_POST['post'] !==''){
        $actual_operation = trim($_POST['post']);
        
        switch ($actual_operation){
        case 'courses':
            include 'admin/courses.php';
            break;
        case 'lecturers':
            include 'admin/lect.php';
            break;
        case 'new_faculty':
        case 'delete_faculty':
            include 'admin/faculty.php';
            break;
        case 'new_department':
        case 'delete_department':
            include 'admin/department.php';
            break;
        case 'account':
            include 'admin/account.php';
            break;
        case 'new_course':
        case 'delete_course':
            include 'admin/courses.php';
            break;
        case 'new_lecturer':
        case 'delete_lecturer':
        case 'update_lecturer':
            include 'admin/lecturers.php';
            break;
        case 'new_student':
        case 'delete_student':
        case 'update_student':
            include 'admin/students.php';
            break;
        case 'register':
            include 'admin/register_course.php';
            break;
        case 'students':
            include 'admin/students_lect.php';
            break;
        }
    }
?>

