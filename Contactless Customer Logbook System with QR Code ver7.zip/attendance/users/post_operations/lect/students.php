<?php
if(isset($_POST['students_btn'])){
    $error = "";
    $success ="";
    
    $course_id = (int) trim($_POST['course']);
    $session = trim($_POST['session']);
    $semester =(int) trim($_POST['semester']);
    
    if(!$course_id || $semester <1 || $session =="none"){
        $error .= "Make all selections.";
    }
    if(strlen($error) <1){
        $_SESSION['s_course_id'] = $course_id;
        $_SESSION['s_session'] = $session;
        $_SESSION['s_semester'] = $semester;
        
        header("Location: students.php");
        //$success = "see ".$course_id.' '.$semester.' '.$session;
    }
}


$qr = $_POST['qr_code'];
$submitbutton= $_POST['qr_code_button'];

if ($submitbutton){
	echo "<script>alert('Success!');</script>";
	if (!empty($qr)) {
	echo 'The name you entered is ' . $qr;
	echo "<script>alert('Success!');</script>";
	}
	/*
	if(isset($_POST['qr_code_button'])){
		

		
	    $error = "";
	    $success = "";

	    
	    $location_code = $_POST['location_code'];
	    $shop_code = $_POST['shop_code'];
	    
	   

	    echo "<script>alert('Success!');</script>";
	    /*
	    $exist = DB::queryFirstRow("SELECT * FROM student WHERE regNo = %s",$qr);
		    if(!empty($exist)){
		        echo "<script>alert('$qr');</script>";
		       $logbook = new Logbook();
		       $student = new Student();
		       //$student->set_regNo($currentDate.$currentDate);
		       $gotStudent = $student->get_name();
		       $logbook->set_name($gotStudent);

		       
		       $success = "Customer found! Logged in successfully.";
		    }
	*/
	
}


    if(strlen($qr) <40 || strlen($qr) >40){
        $error .= "\n Customer qr code must be 40 characters.";
    }
    
    if(strlen($error) <1){
       $student = new Student();
       //$student->set_regNo($currentDate.$currentDate);
       $student->set_regNo($regNo);
       
            $success = "Customer has logged in! ";
        }
    }
    $error = "";
    $success = "";

    $qr = $_POST['qr_code'];
    $location_code = $_POST['location_code'];
    $shop_code = $_POST['shop_code'];
    
   

    echo "<script>alert('Success!');</script>";
    $exist = DB::queryFirstRow("SELECT * FROM student WHERE regNo = %s",$qr);
    if(!empty($exist)){
        echo "<script>alert('$qr');</script>";
       $logbook = new Logbook();
       $student = new Student();
       //$student->set_regNo($currentDate.$currentDate);
       $gotStudent = $student->get_name();
       $logbook->set_name($gotStudent);

       
       $success = "Customer found! Logged in successfully.";
    } else {

    }




    if(strlen($qr) <40 || strlen($qr) >40){
        $error .= "\n Customer qr code must be 40 characters.";
    }
    
    if(strlen($error) <1){
       $student = new Student();
       //$student->set_regNo($currentDate.$currentDate);
       $student->set_regNo($regNo);
       
            $success = "Customer has logged in! ";
        }
    }
?>

