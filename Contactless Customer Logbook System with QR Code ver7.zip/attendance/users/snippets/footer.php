
<footer class="footer noPrint">

<div class="row">
    <div class="col ml-5">


        <ul class="footer-list text-center">

            <li><a href="#">About Attendance Manager</a></li>

           

        </ul>

    </div>

    <div class="col">


        <ul class="footer-list text-center">

            <li><a href="dashboard.php">Dashboard Home</a></li>

           

        </ul>

    </div>


</div>

<div class="row">

<div class="col-12">
    <h6 class="text-center mt-3">Contactless Customer Logbook System &copy; <?php echo date('Y');  ?>. 
        All rights reserved. </h6>

</div>
</footer>
