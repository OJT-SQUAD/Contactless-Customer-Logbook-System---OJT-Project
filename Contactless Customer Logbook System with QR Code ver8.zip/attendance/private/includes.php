<?php
include 'vars.php';
require "phpqrcode/qrlib.php";//Encoder class
require "vendor/autoload.php";//Decoder
include 'src/class.upload.php';//image processor
include 'db_setup.php';
include 'functions.php';
require 'classes/Faculty.php';
require 'classes/Department.php';
require 'classes/Course.php';
require 'classes/Student.php';
require 'classes/Lecturer.php';
require 'classes/RegisteredCourse.php';
require 'classes/Lecture.php';
require 'classes/Attendance.php';


?>

