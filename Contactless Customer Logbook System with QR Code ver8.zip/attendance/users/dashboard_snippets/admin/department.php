

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="4" class="text-center">
                <h2>Shops</h2>
            </th>
        </thead>
        <thead>
            <th>Name</th>
            <th>Code</th>
            <th>Mall/Location</th>
            <td></td>
        </thead>
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='4'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='4'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                    $departments = (new Shop())->fetch_all();
                    foreach($departments as $department){
                        echo '<tr>';
                        echo '<td > '.  ucwords($department->get_name()).'  </td>';
                        echo '<td > '.  ucwords($department->get_code()).'  </td>';
                        echo '<td > '.  ucwords($department->get_faculty()->get_name()).'  </td>';
                        echo '<td > <form method = "post">'
                        
                        . '<input type="hidden" name="department_id" value="'.$department->get_id().'" >'
                                . '<input type="hidden" name ="post" value ="delete_department">'
                                . '<button type="submit"  name="delete_department_btn" class="btn btn-sm btn-outline-danger" > <i class="fa fa-trash"></i> </button>'
                                . '</form></td>';
                        echo '</tr>';
                    }
                ?>
               
    </table>

<form method="post">
      <input type="hidden" name="post" value="new_department" >
      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">New Shop</h5></td>
                    
                </tr>
                
         
                
                <tr>
                    <td><h6>Mall/Location</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="faculty_id" >
                            <option value="0">Select mall/location</option>
                            <?php
                            $faculties = (new Faculty())->fetch_all();
                            foreach($faculties as $faculty){
                                echo '<option value ="'.$faculty->get_id().'" >'.$faculty->get_name().' </option>';
                            }
                            ?>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select location" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Shop Name </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="department_name" >
                            
                            
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                <tr>
                    <td><h6>Shop Code </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="department_code" >
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Enter the Shop code here. e.g. CSC for computer science department" data-content=""></span>
                    </td>
                </tr>
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="new_department_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-plus-square fa-fw"></i> New Shop
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




