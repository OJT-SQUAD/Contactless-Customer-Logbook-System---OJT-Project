

<form method="post">
      <input type="hidden" name="post" value="students" >
      <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     
                 <thead class="bg-success text-white">
                 <th colspan="5" class="text-center">
                <h2>Students Who Registered</h2>
            </th>
        </thead>
    
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='5'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='5' ><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
				
                 <tr>
                    <td><h6>Course </h6></td>
                    <td colspan="3">
                        <select type="text" class="form-control"  name="course" >
                            <option value="0">Select Course</option>
                            <?php 
                            $lect = new Lecturer($_SESSION['id']);
                                $courses = (new Course())->fetch_by_department_id($lect->get_department_id());
                                foreach($courses as $course){
                                    echo '<option value="'.$course->get_id().'"> '.$course->get_name().'|'.$course->get_code().'|Unit: '.$course->get_unit().'</option>';
                                }
                            ?>
                        </select>    
                      
                    </td>
                   <td>
                       &nbsp;&nbsp;
                    </td>
                </tr>
                 
                
                <tr>
                    <td><h6>Session</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="session" >
                            <option value="none">Select Session</option>
                            <option value="2017/2017">2017/2018</option>
                            <option value="2018/2019">2018/2019</option>
                            <option value="2019/2020">2019/2020</option>
                            <option value="2020/2021">2020/2021</option>
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select session" data-content=""></span>
                    </td>
                </tr>
                <tr>
                    <td><h6>Semester</h6></td>
                    <td colspan="3">
                        <select class="form-control" name="semester" >
                            <option value="0">Select Semester</option>
                            <option value="1">First</option>
                            <option value="2">Second</option>
                            
                        </select>
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="Select semester" data-content=""></span>
                    </td>
                </tr>
            
               
               
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="students_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-arrow-right fa-fw"></i> Continue
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




