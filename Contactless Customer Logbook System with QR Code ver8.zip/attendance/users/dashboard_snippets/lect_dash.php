<?php

  if (isset($_GET['tab']) && $_GET['tab'] == 'account') {

        include 'lect/account.php';

   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'students') {

         include 'lect/students.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'continue') {
         include 'lect/continue.php';

   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'start') {

         include 'lect/lecture.php';
  
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'attendance_analyse') {

         include 'lect/query.php';
    
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'ongoing') {

       include 'lect/ongoing.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'lecture') {

       include 'lect/query_lectures.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'lectures') {

       include 'lect/lectures.php';
   }elseif (isset($_GET['tab']) && $_GET['tab'] == 'view_students') {

       include 'lect/view_students.php';
    
}else{
        $message = <<<FMS
            <div class="container mb-5 p-4">
               
                <p>Here is where to manage your details as one of the users of this system.
                With the tabs on the left-sidebar, you can create, view, edit and delete and update establishments, employees, and customers.</p>
                
                <h5>We hope you love your dashboard</h5>
                <quote class="float-right mute muted">
                    <i class="fa fa-heart fa-4x text-green"></i><br>
                    Contactless Logbook</quote>
                <br><br><br>
            </div>
        
FMS;
        echo $message;
    }
    
?>

