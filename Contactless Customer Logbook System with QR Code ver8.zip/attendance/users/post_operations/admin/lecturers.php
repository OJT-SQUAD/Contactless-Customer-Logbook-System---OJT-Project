<?php
if(isset($_POST['new_lecturer_btn'])){
    $error = "";
    $success = "";
    
    $name = trim($_POST['name']);
    
    $department_id = (int)trim($_POST['department_id']);
    $username =   trim($_POST['username']);
    $password = trim($_POST['password']);
    
   
    if(!$department_id){
        $error .= "\n Select department.";
    }
    
   
   
    if(strlen($name) <2 || strlen($name) >50){
        $error .= "\n Lecturer name must be between 2 to 50 characters.";
    }
    if(strlen($username) <2 || strlen($username) > 20){
        $error .= "\n Username must be between 2 to 20 characters.";
    }
    if(strlen($password) <2 || strlen($password) > 20){
        $error .= "\n Password must be between 2 to 20 characters.";
    }
    
    
    $exist = DB::queryFirstRow("SELECT * FROM lecturer WHERE name = %s OR username= %s",$name,$username);
    if(!empty($exist)){
        $error .= "\n Lecturer name and/or username already exists";
    }
    
    if(strlen($error) <1){
        $lect = new Lecturer();
        $lect->set_name($name);
        $lect->set_department_id($department_id);
        $lect->set_username($username);
        $lect->set_password($password);
        if($lect->insert()){
            $success = "Lecturer has been added! ";
        }
    }
    
}
if(isset($_POST['update_lecturer_btn'])){
    $error = "";
    $success = "";
    
   
    
    $department_id = (int)trim($_POST['department_id']);
    $username =   trim($_POST['username']);
    $password = trim($_POST['password']);
    
    $lect_id = (int)trim($_POST['lecturer_id']);
   
    if(!$department_id){
        $error .= "\n Select department.";
    }
    
   
   
    
    if(strlen($username) <2 || strlen($username) > 20){
        $error .= "\n Username must be between 2 to 20 characters.";
    }
    if(strlen($password) <2 || strlen($password) > 20){
        $error .= "\n Password must be between 2 to 20 characters.";
    }
    
    
   $lect = new Lecturer($lect_id);
    if(!$lect->get_id()){
        $error .= "\n Lecturer does not exists";
    }
    
    if(strlen($error) <1){
        
        $lect->set_department_id($department_id);
        $lect->set_username($username);
        $lect->set_password($password);
        if($lect->update_by_id()){
            $success = "Lecturer has been updated! ";
        }
    }
    
}

if(isset($_POST['delete_lecturer_btn'])){
    $error = "";
    $success = "";
    
    $lect_id = trim($_POST['lecturer_id']);
    $lecturer = new Lecturer($lect_id);
    if($lecturer->delete_by_id()){
        $success = "Lecturer has been deleted!";
    }
}
?>


