<?php
if(isset($_POST['students_btn'])){
    $error = "";
    $success ="";
    
    $course_id = (int) trim($_POST['course']);
    $session = trim($_POST['session']);
    $semester =(int) trim($_POST['semester']);
    
    if(!$course_id || $semester <1 || $session =="none"){
        $error .= "Make all selections.";
    }
    if(strlen($error) <1){
        $_SESSION['s_course_id'] = $course_id;
        $_SESSION['s_session'] = $session;
        $_SESSION['s_semester'] = $semester;
        
        header("Location: students.php");
        //$success = "see ".$course_id.' '.$semester.' '.$session;
    }
}
?>

