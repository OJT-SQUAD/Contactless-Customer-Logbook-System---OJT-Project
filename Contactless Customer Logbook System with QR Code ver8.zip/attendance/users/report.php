<?php
include '../private/includes.php';
//import session material and other classes
//check session for a user before proceding

session_start();


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Contactless Customer Logbook System - Log Report</title>
<meta name="author" content="Contactless Customer Logbook System">

<?php require_once('snippets/styles.php');?>
<style type="text/css">
    @media print {
        .noPrint{
            display: none;
        }
    }
</style>
</head>

<body>

<?php
include_once("snippets/header.php");
?>
 
    
   <div class='col-md-12'>
   <div class='main-content'>

 
<?php
if((isset($_SESSION[$user_admin]) && $_SESSION[$user_admin]) || (isset($_SESSION[$user_lect]) && $_SESSION[$user_lect])){
//if(true){//Estate admin
    
    include 'snippets/report.php';

   
       
  }else{
    header("Location: index.php");
}


?>
   </div>
   </div>
    
<?php
include_once("snippets/footer.php");
?>


       
<script>
    $(".details").click(function(){
        var id = this.id;

        $("#to-be-removed_" + id).fadeOut("slow",function(){

            $("#to-replace_" + id).fadeIn("slow");
        })
    })

    $(".back-btn").click(function(){
        var id = this.id;
        name = this.name;

        $("#to-" + id).fadeOut("slow",function(){
            $("#to-be-removed_" + name).fadeIn();
        });
    });
</script>

<?php
include 'snippets/scripts.php';
?>
</body>
</html>

