<?php
$error = "";


    $user ='';
    $user_text = "";
if(isset($_GET['user'])){
    switch (trim($_GET['user'])){
        case "logbook":
            $user_text = "Logbook"; 
            $user = $user_lect;
            break;
        case "admin":
            $user_text = "Admin";
            $user = $user_admin;
            break;
        
    }
}else{
    header("Location: ../index.php");
}

if(isset($_POST['login'])){
    $user = trim($_POST['user']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    switch ($user){
        case $user_admin:
            //
            $admin = DB::queryFirstRow("SELECT * FROM admin WHERE username =%s AND password = %s",$username,$password);
            if(empty($admin)){
                $error = "Wrong username or password";
        }else{
            session_start();
            $_SESSION = array();
                $_SESSION['id'] = (int)$admin['id'];
                $_SESSION['name'] = $admin['name'];
                $_SESSION[$user_admin] = true;
                $_SESSION['qr_login'] = true;
                header("Location: dashboard.php");
                exit;
            }
            break;
        case $user_lect:
            //
             //
            $lect = DB::queryFirstRow("SELECT * FROM lecturer WHERE username =%s AND password = %s",$username,$password);
            if(empty($lect)){
                $error = "Wrong username or password";
        }else{
            session_start();
            $_SESSION = array();
                $_SESSION['id'] = (int)$lect['id'];
                $_SESSION['name'] = $lect['name'];
                $_SESSION[$user_lect] = true;
                  $_SESSION['qr_login'] = true;
                header("Location: dashboard.php");
                exit();
            }
            break;
        
    }
}


?>
 <div class='splash-img'>
    <div class="container login">
    <h1 class="hide">Login</h1>

    <div class="row">

        <div class="col-md-4 col-lg-4 col-xl-4 mx-auto">
            <h3 class="text-center form-head"><a href="../index.php"><i class="fa fa-home"></i></a>&nbsp;&nbsp;&nbsp;<?=$user_text ?> Login</h3>

            <div class="card login">
        
<!--                <small class='alert alert-danger alert-dismissible'>
                <span class='close' data-dismiss='alert'>&times;</span></small>
 -->
                
            <form  method="post" id="">
                <input type="hidden" name="user" value="<?php 
                       echo $user;
                ?>">
                
<!--                <label class="text-black" for="staff_user">Category</label><br>
                <select class="form-control">
                    <option value="lecturer">Lecturer</option>
                    <option value="admin">Admin</option>
                </select><br>-->
                 <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div>";
                 } 
                 
                
                ?>
                
                <label class="text-black" for="username">Username</label><br>
                <input type="text"  name="username" maxlength="20" class="form-control input-text" id="username">
                       
                <label class="text-black" for="password">Password</label><br>
                <input type="password" name="password" maxlength="20" class="input-text form-control" id="password">
 
                <button name="login" class="btn btn-outline-success btn-sm btn-block" type="submit">Login <i class="fa fa-sign-in fa-fw"></i></button>
                <br>
               
               
              
            </form>
            
        </div>
</div>
    </div>
    </div>
 </div>