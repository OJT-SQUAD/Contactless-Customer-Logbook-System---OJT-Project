   <?php
    if(!isset( $_SESSION['report_session']) || !isset( $_SESSION['report_session']) || !isset( $_SESSION['report_session'])){
        header("Location: logout.php");
   }
        $course_id = (int)$_SESSION['report_course'];//int
        $session = $_SESSION['report_session'];
        $semester = (int)$_SESSION['report_semester'];
        $sem = "";
        if($semester ==1){
            $sem = "First";
        }elseif($semester ==2){
            $sem = "Second";
        }
        $rcs = (new RegisteredCourse())->fetch_for_lect($course_id, $session, $semester);
        $all_lectures = (new Lecture())->fetch_lecture_by_course_details($course_id, $session, $semester);
        $course = new Course($course_id);
        
                   
     ?>

    <div class="row">
        <div class="col-md-8 offset-2" >
                <table class="table table-active  bg-white table-lg table-responsive-sm " border="1">
                   
                    <tr>
                        <th colspan="3">Course Title</th>
                        <td colspan="3"><?=  ucwords($course->get_name())?></td>
                    </tr>
                    <tr>
                        <th colspan="3">Course Code</th>
                        <td colspan="3"><?=$course->get_code()?></td>
                    </tr>
                    <tr>
                        <th colspan="3">Unit</th>
                        <td colspan="3"><?=$course->get_unit()?></td>
                    </tr>
                    <tr>
                        <th colspan="3">Session</th>
                        <td colspan="3"><?=$session;
                        ?></td>
                    </tr>
                    <tr>
                        <th colspan="3">Semester</th>
                        <td colspan="3"><?=$sem;
                        ?></td>
                    </tr>
                    <tr>
                        <th colspan="3">No. of Classes</th>
                        <td colspan="3"><?=  count($all_lectures);
                        ?><a href="dashboard.php?tab=lectures&crs=<?=$course_id?>&sem=<?=$semester?>&ses=<?=$session?>"</td>
                    </tr>
                    <tr>
                        <th colspan="3">Estabishments</th>
                        <td colspan="3"><?=(new Lecture())->get_all_lecturers_names($course_id, $session, $semester);
                        ?></td>
                    </tr>
                   

                        <tr class="bg-success">
                            <th><h5>S/N</h5></th>
                            <th><h5>Student Name</h5></th>
                            <th><h5>Reg. No.</h5></th>
                            <th><h5>Shop</h5></th>
                            <th><h5>Classes Attended / <?=count($all_lectures)?></h5></th>
                            <th><h5>Attendance (%)</h5></th>
                       
                        </tr>
                 
                   
                    <?php
                    
                    $counter =1;
                     $students  = array();
                     $lecture_count = count($all_lectures);
                    if(!empty($all_lectures)){

                        $ss =1;
                    foreach($all_lectures as $lecture){
                       $atts = (new Attendance())->fetch_by_lecture($lecture->get_id());
                       
                      
                       for($i=0; $i<count($atts); $i++){
                           $phoneNum = trim($atts[$i]->get_phoneNum());
                           //if(array_key_exists($phoneNum, $students)){
                              
                               $students[$phoneNum][] = $atts[$i];
                           //}else{
                            //   $students[$phoneNum] = array($att);
                           //}
                           
                       }
                       
                    }
                    
                    foreach($students as $key => $att_arr){
                        $student = (new Student())->fetch_student_by_phoneNum($key);
                        
                        echo '<tr>';

                        echo '<td> '. $counter.'</td>';
                        echo '<td> '.$student->get_name().'</td>';
                        echo '<td> '.$student->get_phoneNum().'</td>';
                        echo '<td> '.$student->get_department()->get_name().'</td>';
                        echo '<td> '.count($att_arr).'</td>';
                        
                       $lect_percent = number_format((count($att_arr)/$lecture_count)*100, 1);
                      echo '<td> '.$lect_percent.'</td>';
                        echo '</tr>';
                        $counter++;
                    }
                    ?>
                
                    
                 <?php

                    }else{
                        echo '<tr><td colspan="6"><p class="text-center">No report for this course yet!</p></td>  </tr>';
                    }
                 ?>
                </table>

             </div>
    </div>
    <div class="row noPrint">
        <div class="col-md-2 offset-5">
            <a href="javascript:window.print()" style="margin-top: 5px;" class="btn btn-outline-success btn-sm btn-block"><i class="fa fa-print fa-fw"></i> Print Report</a>
        </div>
    </div>

