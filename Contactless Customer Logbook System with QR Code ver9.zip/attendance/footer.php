</div>
<footer class="footer">

<div class="row">
    <div class="col ml-5">


        <ul class="footer-list text-center">

            <li><a href="about.php">About Leave Manager</a></li>

            <li><a href="sitemap.php">Sitemap</a></li>

        </ul>

    </div>

    <div class="col">


        <ul class="footer-list text-center">

            <li><a href="members.php">Group Members</a></li>

            <li><a href="tutor.php">About Shop</a></li>

        </ul>

    </div>


</div>

<div class="row">

<div class="col-12">
    <h6 class="text-center mt-3">Leave Manager &copy; <?php echo date('Y'); ?>. 
        All rights reserved</h6>

</div>
</footer>
<?php
include 'scripts.php';
?>
</body>
</html>
