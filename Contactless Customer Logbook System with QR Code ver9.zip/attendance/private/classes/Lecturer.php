<?php
class Lecturer{
    private $id;
    private $name;
    private $department_id;
    private $username;
    private $password;
    private $date;
    
    private $department;
    
    public function __construct($id =0) {
        if($id<1){
            $this->id =0;
            $this->name ="none";
            $this->department_id = 0;
            $this->username = "none";
            $this->password  = "none";
            $this->date  = date("Y-m-d H:i:s");
            
            $this->department = null;
        }else{
            $this->fetch_lecturer_by_id($id);
        }
    }

    public function fetch_lecturer_by_id($id) {
        $row = DB::queryFirstRow("SELECT * FROM lecturer WHERE id=%i",$id);
        return $this->set_row($row);
    }
    public function fetch_lecture_department($department_id){
        $result = DB::query("SELECT * FROM lecturer WHERE department=%i",$department_id);
        return $this->set_result($result);
    }
    public function fetch_all(){
        $result = DB::query("SELECT * FROM lecturer");
        return $this->set_result($result);
    }
    
    public function update_by_id(){
        DB::update("lecturer",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function delete_by_id(){
        DB::delete("lecturer","id=%i",  $this->id);
        return true;
    }
    public function insert(){
        DB::insert("lecturer",  $this->get_array());
        return true;
    }

    private function set_row($row) {
        if(!empty($row)){
            $this->id = (int)$row['id'];
            $this->name = $row['name'];
            $this->department_id = (int)$row['department'];
            $this->username = $row['username'];
            $this->password = $row['password'];
            $this->date = $row['date'];
            
            $this->department = new Shop($this->department_id);
            
        }
        return $this;
   }
   private function set_row1($row) {
        $lect = new self();
        if(!empty($row)){
            $lect->id = (int)$row['id'];
            $lect->name = $row['name'];
            $lect->department_id = (int)$row['department'];
            $lect->username = $row['username'];
            $lect->password = $row['password'];
            $lect->date = $row['date'];
            
            $lect->department = new Shop($lect->department_id);
            
        }
        
        return $lect;
    }
    public function  get_array($include_id = false){
        $lect = array();
        if($include_id){
            $lect['id'] = $this->id;
            
        }
        $lect['name'] = $this->name;
        $lect['department'] = $this->department_id;
        $lect['username'] = $this->username;
        $lect['password'] = $this->password;
        $lect['date'] = $this->date;
        return $lect;
    }

    private function set_result($result){
        $lect = array();
        foreach($result as $row){
            $lect[] = $this->set_row1($row);
        }
        return $lect;
    }
    
    public function get_id() {
        return $this->id;
    }

    public function get_name() {
        return $this->name;
    }

    public function get_department_id() {
        return $this->department_id;
    }

    public function get_username() {
        return $this->username;
    }

    public function get_password() {
        return $this->password;
    }

    public function get_date() {
        return $this->date;
    }

    public function get_department() {
        return $this->department;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_name($name) {
        $this->name = $name;
    }

    public function set_department_id($department_id) {
        $this->department_id = $department_id;
    }

    public function set_username($username) {
        $this->username = $username;
    }

    public function set_password($password) {
        $this->password = $password;
    }

    public function set_date($date) {
        $this->date = $date;
    }

    public function set_department($department) {
        $this->department = $department;
    }

 

}
?>

