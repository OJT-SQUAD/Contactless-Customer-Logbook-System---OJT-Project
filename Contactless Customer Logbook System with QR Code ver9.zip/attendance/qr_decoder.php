<?php
require "vendor/autoload.php";
$qrcode = new Zxing\QrReader('qr_codes/wilson.png');
$text = $qrcode->text(); //return decoded text from QR Code
echo $text;

?>