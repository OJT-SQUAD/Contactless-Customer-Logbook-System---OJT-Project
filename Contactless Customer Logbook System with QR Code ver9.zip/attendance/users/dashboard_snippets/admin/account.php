

    
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="2" class="text-center">
                <h2>My Account</h2>
            </th>
        </thead>
       
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
                <?php
                $admin = DB::queryFirstRow("SELECT * FROM admin WHERE id =%i",$_SESSION['id']);
                ?>
        <tr><th>Admin Name</th>
            <td><?=  ucwords($admin['name']);?>
            </td>
        </tr>
        <tr><th>Username</th>
            <td><?=$admin['username'];?>
            </td>
        </tr>
        <tr><th>Password</th>
            <td><?=$admin['password'];?>
            </td>
        </tr>
    </table>

<form method="post">
      <input type="hidden" name="post" value="account" >
      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
     <tr class="bg-success text-white">
                     <td colspan="5"><h5 class="text-center">Account Update</h5></td>
                    
                </tr>
                
         
                
          
                <tr>
                    <td><h6>New Password </h6></td>
                    <td colspan="3">
                        <input type="text" class="form-control" name="new_password" >
                            
                            
                      
                    </td>
                   <td>
                        <span class="fa fa-info-circle info " data-toggle="popover"
                               title="password must not be more than 20 characters" data-content=""></span>
                    </td>
                </tr>
                
                         
                
             
               
               
                
                 <tr>
                     <td colspan="4"><button name="account_btn" type="submit" class="btn btn-sm btn-outline-success ">
                            <i class="fa fa-lock fa-fw"></i> Update
                    </button>
                    </td>
                   
                    <td >
                        &nbsp;&nbsp;
                    </td>
                </tr>
                
      </table>      
</form>




