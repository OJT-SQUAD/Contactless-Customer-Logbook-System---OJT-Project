$(function(){
   $("#applicant").hide();
   $("#company").hide();
   
   $("admin_lecturer_delete_btn").on('click',function(){
      if(confirm("Are you sure you want to delete this information?")){
          $("admin_lecturer_delete_form").submit();
      } 
   });
  
   
   //lecture ongoing
   $("#spinner").hide();
});


function hide(id){
    $("#"+id).hide();
}
function show(id){
    $("#"+id).show();
}