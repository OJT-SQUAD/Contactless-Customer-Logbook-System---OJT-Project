   <?php
                   $student = new Student();
                   if(isset($_GET['id']) && is_numeric($_GET['id'])){
                       $id = (int)trim($_GET['id']);
                       $row = DB::queryFirstRow("SELECT * FROM student WHERE id=%i",$id);
                       if(count($row) >0){
                           $student = $student->fetch_student_by_id($id);
                         }
                   }
                   if(!$student->get_id()){
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>

    <div class="row">
        <div class="col-md-4 offset-4" style="border:1px black solid;">
            <div class="card-header centered">
                <h4 class="text-center">Customer's Card</h4>
                <img class="card-img-top" width="30" src="qrcode_images/<?=  strtolower(str_replace("/", "", $student->get_Name()))?>.png" alt="Image name">
            </div>
            <div class="card-body">
                <h5 class="card-title"><?= ucwords($student->get_name())?></h5>
                <p class="card-text">
                    <span >Address : </span><span><?= ucwords($student->get_address())?></span><br>
                    <span >Phone # : </span><span><?= $student->get_phoneNum()?></span><br>
                    <span >Barangay : </span><span><?= ucwords($student->get_barangay())?></span>
                </p>
            </div>
        </div>
    </div>
    <div class="row noPrint">
        <div class="col-md-2 offset-5">
            <a href="javascript:window.print()" style="margin-top: 5px;" class="btn btn-outline-success btn-sm btn-block"><i class="fa fa-print fa-fw"></i> Print</a>
        </div>
    </div>

