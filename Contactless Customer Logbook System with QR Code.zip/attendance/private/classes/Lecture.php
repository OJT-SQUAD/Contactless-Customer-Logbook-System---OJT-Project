<?php
class Lecture{
    private $id;
    private $course_id;
    private $lecturer_id;

    private $location;
    private $shop;

    private $session;
    private $semester;
    private $in_progress;
    private $start;
    private $stop;
    private $duration;
    
    private $course;
    private $lecturer;
    
    public function __construct($id =0) {
        if($id<1){
            $this->id =0;
            $this->course_id=0;
            $this->lecturer_id = 0;

            $this->location = "";
            $this->shop = "";  
                      
            $this->session = "none";
            $this->semester = 0;
            $this->in_progress =1;
            $this->duration = 0;
            $this->start = date("Y-m-d H:i:s");
            $this->stop = date("Y-m-d H:i:s");
            
            $this->course = null;
            $this->lecturer = null;
        }else{
            $this->fetch_lecture_by_id($id);
                    
        }
    }

    public function fetch_lecture_by_id($id) {
        $row = DB::queryFirstRow("SELECT * FROM lecture WHERE id=%i",$id);
        return $this->set_row($row);
    }
    public function fetch_location($id) {
        $row = DB::queryFirstRow("SELECT * FROM lecture WHERE id=%i",$id);
        return $this->set_row($row);
    }
    public function fetch_lecture_by_lecturer($lecturer_id) {
        $result = DB::query("SELECT * FROM lecture WHERE lecturer=%i",$lecturer_id);
        return $this->set_result($result);
    }
    public function fetch_lecture_by_lect_in_progress($lecturer_id) {
        $row = DB::queryFirstRow("SELECT * FROM lecture WHERE lecturer=%i",$lecturer_id);
        return $this->set_row($row);
    }
    public function fetch_lecture_by_lecturer_details($lecturer_id,$session, $semester) {
        $result = DB::query("SELECT * FROM lecture WHERE lecturer=%i AND session =%s AND semester=%i",$lecturer_id,$session,$semester);
        return $this->set_result($result);
    }
    public function fetch_lecture_by_course_details($course_id,$session, $semester) {
        $result = DB::query("SELECT * FROM lecture WHERE course=%i AND session =%s AND semester=%i",$course_id,$session,$semester);
        return $this->set_result($result);
    }
     public function fetch_lecture_by_course($course_id) {
        $result = DB::query("SELECT * FROM lecture WHERE course=%i",$course_id);
        return $this->set_result($result);
    }
    
    public function update_by_id(){
        DB::update("lecture",  $this->get_array(),"id=%i",  $this->id);
        return true;
    }
    public function delete_by_id(){
        DB::delete("lecture","id=%i",  $this->id);
        return true;
        
    }
    public function get_all_lecturers_names($course_id, $session, $semester){
        $result = DB::query("SELECT DISTINCT lecturer FROM lecture WHERE course =%i AND session =%s AND semester =%i",$course_id,$session,$semester);
        $count = count($result);
        $names = "";
        if($result >0){
            $id = (int)$result[0]['lecturer'];
            $lect1 = new Lecturer($id);
            $names = $lect1->get_name();
            
            for($i =1; $i<$count; $i++){
                $id = (int)$result[$i]['lecturer'];
                $lect = new Lecturer($id);
                $names .= ", ".$lect->get_name();
             }
        }
        return $names;
        
    }

    public function insert(){
        DB::insert("lecture",  $this->get_array());
        return true;
    }

    private function set_row($row) {
        if(!empty($row)){
            $this->id = (int)$row['id'];
            //$this->course_id = (int)$row['course'];
            $this->lecturer_id = (int)$row['lecturer'];

            $this->location = (int)$row['Location'];
            $this->shop = (int)$row['Shop'];            
            //$this->session = $row['session'];
            //$this->semester = (int)$row['semester'];
            //$this->in_progress =(int)$row['in_progress'];
            //$this->start = $row['start'];
            //$this->duration = (int)$row['duration'];
            //this->stop = $row['stop'];
            
            $this->course = new Course($this->course_id);
            $this->lecturer = new Lecturer($this->lecturer_id);
                    
        }
        return $this;
    }
    private function set_row1($row) {
        $lc = new self();
        if(!empty($row)){
            $lc->id = (int)$row['id'];
            $lc->course_id = (int)$row['course'];
            $lc->lecturer_id = (int)$row['lecturer'];
            $lc->session = $row['session'];
            $lc->semester = (int)$row['semester'];
            $lc->in_progress = (int)$row['in_progress'];
            $lc->start= $row['start'];
            $lc->duration = (int)$row['duration'];
            $lc->stop= $row['stop'];
            
            $lc->course = new Course($lc->course_id);
            $lc->lecturer = new Lecturer($lc->lecturer_id);
                    
        }
        return $lc;
    }
    
    public function get_array($include_id = false){
        $lc = array();
        if($include_id){
            $lc['id'] = $this->id;
            
        }
        $lc['course'] = $this->course_id;
        $lc['lecturer'] = $this->lecturer_id;

        $lc['Location'] = $this->location;
        $lc['Shop'] = $this->shop;

        $lc['session'] = $this->session;
        $lc['semester'] = $this->semester;
        $lc['duration'] = $this->duration;
        $lc['in_progress'] =  $this->in_progress;
        $lc['start'] = $this->start;
        $lc['stop'] = $this->stop;
        
        return $lc;
                
    }
    public function set_result($result){
        $lc = array();
        foreach($result as $row){
            $lc[] = $this->set_row1($row);
        }
        return $lc;
                
    }
    public function get_in_progress() {
        return $this->in_progress;
    }

    public function set_in_progress($in_progress) {
        $this->in_progress = $in_progress;
    }

        public function get_id() {
        return $this->id;
    }

    public function get_course_id() {
        return $this->course_id;
    }

    public function get_lecturer_id() {
        return $this->lecturer_id;
    }
    public function get_location() {
        return $this->location;
    }
    public function get_shop() {
        return $this->shop;
    }

    public function get_session() {
        return $this->session;
    }

    public function get_semester() {
        return $this->semester;
    }

    public function get_duration() {
        return $this->duration;
    }

    public function set_duration($duration) {
        $this->duration = $duration;
    }

    
    public function get_course() {
        return $this->course;
    }

    public function get_lecturer() {
        return $this->lecturer;
    }

    public function set_id($id) {
        $this->id = $id;
    }

    public function set_course_id($course_id) {
        $this->course_id = $course_id;
    }

    public function set_lecturer_id($lecturer_id) {
        $this->lecturer_id = $lecturer_id;
    }

    public function set_session($session) {
        $this->session = $session;
    }

    public function set_semester($semester) {
        $this->semester = $semester;
    }

    public function get_start() {
        return $this->start;
    }

    public function get_stop() {
        return $this->stop;
    }

    public function set_start($start) {
        $this->start = $start;
    }

    public function set_stop($stop) {
        $this->stop = $stop;
    }

    
    public function set_course($course) {
        $this->course = $course;
    }

    public function set_lecturer($lecturer) {
        $this->lecturer = $lecturer;
    }



}
?>

