<li class="list-main">
                        <a href="dashboard.php?tab=faculty">
                            <i class="fa fa-building icon"></i>
                            <span class="extra-sm break">Shopping Location</span>
                        </a>
                    </li>  
            <li class="list-main">
                        <a href="dashboard.php?tab=department">
                            <i class="fa fa-building icon"></i>
                            <span class="extra-sm break">Shops</span>
                        </a>
                    </li>  
     <li class="list-main">
                        <a href="dashboard.php?tab=courses">
                            <i class="fa fa-book icon"></i>
                            <span class="extra-sm break">Courses</span>
                        </a>
                    </li> 
     <li class="list-main">
                        <a href="dashboard.php?tab=lecturers">
                            <i class="fa fa-users icon"></i>
                            <span class="extra-sm break">Estabishments</span>
                        </a>
                    </li> 
     <li class="list-main">
                        <a href="dashboard.php?tab=students">
                            <i class="fa fa-users icon"></i>
                            <span class="extra-sm break">Register/View Customers</span>
                        </a>
                    </li> 
     <li class="list-main">
                        <a href="dashboard.php?tab=register">
                            <i class="fa fa-plus icon"></i>
                            <span class="extra-sm break">Register Course/Students</span>
                        </a>
    </li> 
     <li class="list-main">
                        <a href="dashboard.php?tab=register_lect">
                            <i class="fa fa-plus icon"></i>
                            <span class="extra-sm break">Register Course/Shop</span>
                        </a>
    </li> 
    