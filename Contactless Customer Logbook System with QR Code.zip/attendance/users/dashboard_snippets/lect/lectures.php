

      <?php
                  
                   $course =null;
                   $semester = "";
                   $session = "";
                   $semm=0;
                   if(isset($_GET['crs']) && is_numeric($_GET['crs']) && isset($_GET['sem']) && is_numeric($_GET['sem']) && isset($_GET['ses'])){
                       $id = (int)trim($_GET['crs']);
                       $sem = (int)trim($_GET['sem']);
                       $semm= $sem;
                       $session = trim($_GET['ses']);
                       if($sem ==2){
                           $semester = "Second";
                       }else if($sem==1){
                           $semester = "First";
                       }
                       $row = DB::queryFirstRow("SELECT * FROM course WHERE id=%i",$id);
                       if(count($row) >0){
                           $course = new Course($id);
                         }
                   }else{
                        header("Location: dashboard.php");
                   }
                   if(!$course->get_id()){
                       header("Location: dashboard.php");
                   }
                    
                   
                ?>
    <table class="table table-active table-lg table-responsive-sm w-100">
        <thead class="bg-success text-white">
        <th colspan="2" class="text-center">
                <h2>Lectures</h2>
            </th>
        </thead>
       
        
       
                         <?php
               //$error ="";
              // $success = "Details has been updated!";
                 if(strlen(trim($error)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-danger alert-dismissible'>"
                    .$error."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                 
                 if(strlen(trim($success)) >0){
                     echo "<tr><td colspan='2'><div class='alert alert-success alert-dismissible'>"
                    .$success."<span class='close' data-dismiss='alert'>"
                    . "&times;</span></div></td></tr>";
                 } 
                ?>
        
               
        <tr><th>Course Title</th>
            <td><?= ucwords($course->get_name());?>
            </td>
        </tr>
        <tr><th>Course Code</th>
            <td><?= $course->get_code();?>
            </td>
        </tr>
        <tr><th>Course Unit</th>
            <td><?= $course->get_unit();?>
            </td>
        </tr>
        <tr><th>Session</th>
            <td><?= $session;?>
            </td>
        </tr>
        <tr><th>Semester</th>
            <td><?= $semester;?>
            </td>
        </tr>
        
       
       
    </table>

      <table class="table table-active table-hover table-lg table-responsive-sm w-100">
          <tr>
              <th>S/N</th>
              <th>Date</th>
              <th>Start</th>
              <th>Duration</th>
              <th>Lecturer</th>
              <th></th>
          </tr>
          <?php
          
          $lectures = (new Lecture())->fetch_lecture_by_course_details($course->get_id(), $session, $semm);
          $counter =1;
          foreach ($lectures as $lect){
              echo '<tr>';
              echo '<td>'.$counter.' </td>';
              echo '<td>'.date("D. jS M., Y",  strtotime($lect->get_start())).' </td>';
              echo '<td>'.date("h:i A",  strtotime($lect->get_start())).' </td>';
              echo '<td>'.$lect->get_duration().' </td>';
              echo '<td>'.$lect->get_lecturer()->get_name().' </td>';
              echo '<td><a class="btn btn-sm btn-outline-success" href="dashboard.php?tab=view_students&lecture='.$lect->get_id().'">View students </a>  </td>';
             
              echo '</tr>';
              $counter++;
          }
          ?>
                
         
           
                         
                
             
               
               
                
              
                
      </table>      




