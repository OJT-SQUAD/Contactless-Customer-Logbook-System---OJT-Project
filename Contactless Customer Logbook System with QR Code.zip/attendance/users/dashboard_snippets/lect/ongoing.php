<?php
$lect = new Lecturer($_SESSION['id']);
//$loc = new Lecture($_SESSION['id']);
//check if there is a lecture in progress
$loc = (new Lecture())->fetch_location($_SESSION['id']);
/*$start_duration = strtotime($lecture->get_start()) + ($lecture->get_duration() * 60 * 60);
/*
$on = $start_duration > time();
if(!($lecture->get_id() >0 && $on)){
    
   <?php header("Location: logout.php");
}

$_SESSION['lecture_id'] = $lecture->get_id();
*/
?>
  <table class="table table-active table-hover table-lg table-responsive-sm  w-100">
     
                 <thead class="bg-success text-white">
                 <th colspan="2" class="text-center">
                     <h2>Contactless Logbook</h2>
            </th>
        </thead>
        <tr>
            <th>Date</th>
            <td><?=date("D, jS M., Y")?></td>
        </tr>
        <tr>
            <th>In-charge</th>
            <td><?=$lect->get_name()?></td>
        </tr>
        <tr>
            <th>Location</th>
            <td><?=$loc->get_location()?></td>
        </tr>
        <tr>
            <th>Shop</th>
            <td><?=$lect->get_shop()?></td>
        </tr>


  </table>
 <div class="container">
     <input type="hidden" id="lecture_id" value="<?=$lecture->get_id()?>" >
        <div class="row">
        <div class="col-md-8">
            <div class="text-center">
                <div   >
                    <span class="text-center text-success" id="spinner"><i class="fa fa-spin fa-spinner fa-2x"></i></span>
                </div>
                <div id="camera" style="margin:0 auto; width: 50%;height: 350px;"></div><br>
    <button id="take_snapshots" class="btn btn-success btn-sm"><i class="fa fa-camera fa-fw"></i> Take Shot</button>
      </div>
        </div>
        <div class="col-md-4">
            <table class="table table-bordered" id="result_table">
                       
        </table>
        </div>
 </div>
    </div> <!-- /container -->